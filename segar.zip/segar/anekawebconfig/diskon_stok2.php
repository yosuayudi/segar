<?php
    // diskon  
	$harga     =  number_format(($r[harga]),0,",",".");
    $disc      = ($r[diskon]/100)*$r[harga];
    $hargadisc = number_format(($r[harga]-$disc),0,",",".");

    $d=$r['diskon'];
    $hargatetap  = "<span class='special-price'> 
				    <span class='price'>Rp. $hargadisc</span> </span>";
    $hargadiskon = "<div class='label_sale_top_right'>$r[diskon]%</div>
	                <span class='old-price'> 
				    <span class='price'>Rp. $harga</span> </span> 
				    <span class='special-price'> 
				    <span class='price'>Rp. $hargadisc</span> </span> ";
					 
					 
    if ($d!=0){
      $divharga=$hargadiskon;
    }else{
      $divharga=$hargatetap;
    } 

    // tombol stok habis kalau stoknya 0
    $stok        = $r['stok'];
    $tombolbeli  = "<i class='icon-basket'></i>Beli Produk";
    $tombolhabis = "<div class='anekaweb-detail-stokhabis img-rounded'></div>
	                <div class='product-tocart'> 
	                <i class='icon-basket-1'></i>Stok Habis </div>";
    if ($stok!=0){
      $tombol=$tombolbeli;
    }else{
      $tombol=$tombolhabis;
    } 
?>

