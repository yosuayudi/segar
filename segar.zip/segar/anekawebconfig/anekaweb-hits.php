 <?php
	  $ip=$_SERVER['REMOTE_ADDR'];
		$tanggal=date("d-m-Y");
		$tgl=date("d");
		$bln=date("m");
		$thn=date("Y");
		$tglk=$tgl-1;
		$baca=mysql_query("SELECT * FROM konter WHERE ip='$sip' AND tanggal='$stgl' AND waktu='$sjam'");
		$baca1=mysql_num_rows($baca);
		if($baca1==0){
			$tkonter=mysql_query("INSERT INTO konter VALUES ('$sip','$stgl','$sjam')");
		}
			$q=mysql_query("SELECT * FROM konter");
			$blan=date("m-Y");
			$bulan=mysql_query("SELECT * FROM konter WHERE tanggal LIKE '%$blan%'");
			$tahunini=mysql_query("SELECT * FROM konter WHERE tanggal LIKE '%$thn%'");
			$today=mysql_query("SELECT * FROM konter WHERE tanggal='$tanggal'");
		    if($tglk=='1' | $tglk=='2' | $tglk=='3' | $tglk=='4' | $tglk=='5' | $tglk=='6' | $tglk=='7' | $tglk=='8' | $tglk=='9'){
		    $kemarin=mysql_query("SELECT * FROM konter WHERE tanggal='0$tglk-$bln-$thn'");
		    } else {
			$kemarin=mysql_query("SELECT * FROM konter WHERE tanggal='$tglk-$bln-$thn'");
			}
			$visitor = mysql_num_rows($q);
			$bulan1=mysql_num_rows($bulan);
			$tahunini1=mysql_num_rows($tahunini);
			$kemarin1 = mysql_num_rows($kemarin);
			$todays=mysql_num_rows($today);
		 ?>
  <p>Online: <?php include "anekawebconfig/useronline.php"; ?><span class="jeda">|</span>Hits Hari Ini: <?=$todays;?>
  <span class="jeda">|</span>Total Hits: <?=$visitor;?></p>
 