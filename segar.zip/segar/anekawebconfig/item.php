<?php
	  $sid = session_id();
	  $aneka= mysql_query("SELECT SUM(jumlah*(harga-(diskon/100)*harga)) as total,SUM(jumlah) as totaljumlah FROM orders_temp, produk 
	  WHERE id_session='$sid' AND orders_temp.id_produk=produk.id_produk");
	  while($r=mysql_fetch_array($aneka)){
	  if ($r['totaljumlah'] != ""){
	  $total_rp    =  number_format(($r['total']),0,",",".");

 
echo "<div class='fadelink'>
	  <span class='pull-right'> 
	  <a href='keranjang-belanja.html' class='btn'><i class='icon-basket icon-large'></i></a> </span>
	  <span class='badge  badge-inverse'>$r[totaljumlah]</span>  
	  <div class='shopping_cart_mini hidden-phone hidden-tablet'>
	  <div class='inner-wrapper'>";
  
	  $aneka1 = mysql_query("SELECT * FROM orders_temp, produk 
	  WHERE id_session='$sid' AND orders_temp.id_produk=produk.id_produk");
	  while($r=mysql_fetch_array($aneka1)){
		 
	  $disc        = ($r[diskon]/100)*$r[harga];
	  $hargadisc   = number_format(($r[harga]-$disc),0,",",".");
	  $harga       = format_rupiah($r[harga]);
	
echo "<div class='item'> 
      <a href='produk-$r[id_produk]-$r[produk_seo].html' class='product-image'>
      <img src='$anekaweb/images/produk/$r[gambar]' width='45' alt='$r[nama_produk]'></a>
      <div class='product-detailes'> 
	  <a href='produk-$r[id_produk]-$r[produk_seo].html' class='product-name'>$r[nama_produk]</a>
      <div class='product-price'>$r[jumlah] x Rp. $hargadisc</div>
      </div>";
	  }
  
	  $sid = session_id();
	  $aneka2 = mysql_query("SELECT SUM(jumlah*(harga-(diskon/100)*harga)) as total,SUM(jumlah) as totaljumlah FROM orders_temp, produk 
	  WHERE id_session='$sid' AND orders_temp.id_produk=produk.id_produk");
	  while($r=mysql_fetch_array($aneka2)){
	  if ($r['totaljumlah'] != ""){
	  $total_rp    =  number_format(($r['total']),0,",",".");
 
echo "</div>
      <div class='wrapper'><b> Total: Rp. $total_rp,- </b>
	  <a href='selesai-belanja.html' class='button'>Selesai Belanja</a> </div>";
	  }
	  }
echo "</div>
	  </div>
	  </div>";
	  } 
      else{
echo "<div class='fadelink'>
	  <span class='pull-right'> 
	  <a href='#' class='btn'><i class='icon-basket icon-large'></i></a> </span>
	  <span class='badge  badge-inverse'>0</span>
	  <div class='shopping_cart_mini hidden-phone hidden-tablet'>
	  <div class='inner-wrapper'>
	  <div class='item'>
	  <div class='product-detailes'> 
	  <a href='semua-produk.html' class='product-name'>Keranjang Belanja Anda Masih Kosong</a>
	  </div>
	  </div>
	  </div>
	  </div>
	  </div>";}}
   
  ?>