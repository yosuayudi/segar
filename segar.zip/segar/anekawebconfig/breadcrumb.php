<?php
if($_GET['module']=='store'){
	echo "<a href='index.php'>Beranda</a>";
}
elseif($_GET['module']=='profilkami'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Profil Kami";
}
elseif($_GET['module']=='carapemesanan'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Cara Pemesanan";
}
elseif($_GET['module']=='semuablog'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Semua Blog";
}
elseif($_GET['module']=='semuaproduk'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Semua Produk";	
}
elseif($_GET['module']=='semuadownload'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Download Katalog";
}
elseif($_GET['module']=='keranjangbelanja'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Keranjang Belanja";
}
elseif($_GET['module']=='kontak'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Kontak Kami";
}
elseif($_GET['module']=='kontakaksi'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Kontak Kami";
}
elseif($_GET['module']=='hasilcari'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Hasil Pencarian";
}
elseif($_GET['module']=='selesaibelanja'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Selesai Belanja";
}
elseif($_GET['module']=='simpantransaksi'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Transaksi Selesai";
}
elseif($_GET['module']=='daftar'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Daftar Anggota";
}
elseif($_GET['module']=='login'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Login Anggota";
}
elseif($_GET['module']=='lupapassword'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Lupa Password";
}
elseif($_GET['module']=='profil'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Member Profil Anda";
}
elseif($_GET['module']=='lihatorder'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Order Anda";
}
elseif($_GET['module']=='tampilorder'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Konfirmasi Order";
}
elseif($_GET['module']=='testimonial'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Testimonial";
}
elseif($_GET['module']=='testimonialaksi'){
	echo "<a href='index.php'>Home</a> <span>&#8250;</span>Testimonial";
}
elseif($_GET['module']=='detailproduk'){
	
	$detail	=mysql_query("SELECT * FROM produk   
                                   WHERE kategori_seo like '%".strip_tags($_GET['kategori_seo'])."%'
                                   AND id_produk='$_GET[id]'");
	$d		= mysql_fetch_array($detail);
echo "<a href='index.php'>Beranda</a> <span>&#8250;</span> <a href='semua-produk.html'>Produk</a> <span>&#8250;</span> 
      <a href='kategoriproduk-$d[id_kategori]-$d[kategori_seo].html'>$d[nama_kategori]</a> <span>&#8250;</span> <a href='#'>$d[nama_produk]</a>";
}
elseif($_GET['module']=='detailkategori'){
	$detail	=mysql_query("SELECT nama_kategori from kategoriproduk where kategori_seo like '%".strip_tags($_GET['kategori_seo'])."%'");
	$d		= mysql_fetch_array($detail);
echo "<a href='index.php'>Beranda</a> <span>&#8250;</span> <a href=''>$d[nama_kategori]</a> ";
}
elseif($_GET['module']=='detailblog'){
	$detail	=mysql_query("SELECT * FROM blog,users,kategoriblog    
            	          WHERE users.username=blog.username 
                	      AND kategoriblog.id_kategoriblog=blog.id_kategoriblog 
                     	  AND id_blog='$_GET[id]'");
	$d		= mysql_fetch_array($detail);
echo "<a href='index.php'>Beranda</a> <span>&#8250;</span> <a href='semua-blog.html'>Blog</a>
      <span>&#8250;</span> <a href=kategori-$d[id_kategoriblog]-$d[kategoriblog_seo].html'>$d[nama_kategoriblog]</a><span>&#8250;</span> <a href='#'>$d[judul]</a>";
}
elseif($_GET['module']=='halamanstatis'){
	$detail	=mysql_query("SELECT * FROM halamanstatis    
                      WHERE id_halaman
                      AND id_halaman='$_GET[id]'");
	$d		= mysql_fetch_array($detail);
echo "<li>$d[judul]</li>";
}
?>
