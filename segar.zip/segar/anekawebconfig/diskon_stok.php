<?php
	if(isset($_POST['ajax'])){
	error_reporting(0);
  		include "../config/koneksi.php";
  		include "../config/fungsi_rupiah.php";
		
	mysql_query("update produk set diskon='0' where id_produk='$_POST[id_produk]'");
	$r = mysql_fetch_array(mysql_query("select * from produk where id_produk='$_POST[id_produk]'"));
	}
    // diskon  
	$harga     =  number_format(($r[harga]),0,",",".");
    $disc      = ($r[diskon]/100)*$r[harga];
    $hargadisc = number_format(($r[harga]-$disc),0,",",".");

    $d=$r['diskon'];
    $hargatetap  = "<span class='new'>Rp. $hargadisc</span> ";
    $hargadiskon = "<div class='sale_discount img-rounded'>$r[diskon]%</div>
	                <span class='new'>Rp. $hargadisc</span> 
					<span class='old'>Rp. $harga</span>";
					 
					 
    if ($d!=0){
      $divharga=$hargadiskon;
    }else{
      $divharga=$hargatetap;
    } 

    // tombol stok habis kalau stoknya 0
    $stok        = $r['stok'];
    $tombolbeli  = "<div class='product-tocart'>
	                <a href=\"aksi.php?module=keranjang&act=tambah&id=$r[id_produk]\">
	                <i class='icon-basket'></i></a> 
					</div>";
    $tombolhabis = "<div class='anekaweb-stokhabis img-rounded'></div>
	                <div class='product-tocart'> 
	                <a href='#'>
					<i class='icon-basket-1'></i></a> </div>";
    if ($stok!=0){
      $tombol=$tombolbeli;
    }else{
      $tombol=$tombolhabis;
     } 
	
	if(isset($_POST['ajax'])){
		echo $divharga;
	} 
?>

