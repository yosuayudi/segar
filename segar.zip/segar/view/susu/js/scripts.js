(function ($) {
    $(document).ready(function () {

        var accordion = $('.accordion');




        // begin collapsed menu
        $('label.tree-toggler').each(function () {
            if ($(this).parent().find('ul.nav-list').length != 0) {
                $(this).append("<span class='collapse_button'>+</span>");
            }
        });
        $('label.tree-toggler span.collapse_button').click(function () {
            if (!$(this).parent().parent().hasClass('active')) {
                $(this).html('&#8211;');
                $(this).addClass('collapsed');
                $(this).parent().parent().children('ul.nav-list').show(300);
                $(this).parent().parent().addClass('active');
            } else {
                $(this).html('+');
                $(this).removeClass('collapsed');
                $(this).parent().parent().find('ul.nav-list').hide(300);
                $(this).parent().parent().removeClass('active');
                $(this).parent().parent().find('li').removeClass('active');
                $(this).parent().parent().find('span.collapse_button').html('+');
            }
        });
        //  end collapsed menu

        // change accordion caret when collapsing
        accordion.find('.accordion-toggle').click(function () {
            if ($(this).hasClass('collapsed')) {
                accordion.find('.accordion-toggle').not(this).addClass('collapsed');
            }
        })

    })


})(jQuery);