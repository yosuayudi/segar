<?php 
error_reporting(0);
session_start();
$iden=mysql_fetch_array(mysql_query("SELECT url FROM identitas"));
$anekaweb="$iden[url]";
   
$tip=$_SESSION['ip'];
$tjam=$_SESSION['jam'];
$ttgl=$_SESSION['tgl'];
if($tip=='' && $tjam=='' && $ttgl==''){				
$ip=$_SERVER['REMOTE_ADDR'];
$jam=date("h:i:s");
$tgl=date("d-m-Y");
$_SESSION ["ip"] = $ip;
$_SESSION ["jam"] = $jam;
$_SESSION ["tgl"] = $tgl;
}
$sip=$_SESSION['ip'];
$sjam=$_SESSION['jam'];
$stgl=$_SESSION['tgl'];

?>

<!DOCTYPE html>
<html>
<head>
 <title><?php include "config/titel.php"; ?></title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="robots" content="index, follow">
  <meta name="description" content="<?php include "config/deskripsi.php"; ?>">
  <meta name="keywords" content="<?php include "config/keyword.php"; ?>">
  <meta http-equiv="Copyright" content="sususegar" "yosua96yudi@gmail.com">
  <meta name="author" content="sususegar">
  <meta http-equiv="imagetoolbar" content="no">
  <meta name="language" content="jawa-Indonesia">
  <meta name="revisit-after" content="7">
  <meta name="webcrawlers" content="all">
  <meta name="rating" content="general">
  <meta name="spiders" content="all">
  <link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="rss.xml" />
  
  <?php 
   $iden=mysql_fetch_array(mysql_query("SELECT * FROM identitas"));
  echo "<link rel='shortcut icon' href='$anekaweb/images/logo/$iden[favicon]' />";
   ?>
  
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="<?php echo "$anekaweb/$f[folder]/css/reset.css" ?>" rel="stylesheet">
<link href="<?php echo "$anekaweb/$f[folder]/css/bootstrap.css" ?>" rel="stylesheet">
<link href="<?php echo "$anekaweb/$f[folder]/css/bootstrap-responsive.css" ?>" rel="stylesheet">
<link href="<?php echo "$anekaweb/$f[folder]/css/flexslider.css" ?>" rel="stylesheet"  />
<link href="<?php echo "$anekaweb/$f[folder]/css/andepict.css" ?>" rel="stylesheet">
<link href="<?php echo "$anekaweb/$f[folder]/css/product-slider.css" ?>" rel="stylesheet"  />
<link href="<?php echo "$anekaweb/$f[folder]/css/jquery.selectbox.css" ?>" rel="stylesheet" />
<link href="<?php echo "$anekaweb/$f[folder]/css/nouislider.css" ?>" rel="stylesheet">
<link href="<?php echo "$anekaweb/$f[folder]/css/fb_style.css" ?>" rel="stylesheet">
<link href="<?php echo "$anekaweb/$f[folder]/css/style.css" ?>" rel="stylesheet">
<link href="<?php echo "$anekaweb/$f[folder]/css/animate.css" ?>" rel="stylesheet">
<link href="<?php echo "$anekaweb/$f[folder]/css/cloud-zoom.css" ?>" rel="stylesheet">
<link href="<?php echo "$anekaweb/$f[folder]/css/ddsmoothmenu.css" ?>" rel="stylesheet">
<link href="<?php echo "$anekaweb/$f[folder]/css/megamenu.css" ?>" rel="stylesheet">
<link href="<?php echo "$anekaweb/$f[folder]/css/font-awesome.min.css" ?>" rel="stylesheet">
<link href="<?php echo "$anekaweb/$f[folder]/css/camera.css" ?>" rel="stylesheet">
<!--[if IE 9 ]><link href="css/styleie9.css" rel="stylesheet"> <![endif]-->
<!--[if lte IE 8 ]> <link href="css/styleie8.css" rel="stylesheet"> <script src="js/html5.js"></script><![endif]-->
<script src="<?php echo "$anekaweb/$f[folder]/js/jquery-1.7.2.min.js" ?>"></script>
<script src="<?php echo "$anekaweb/$f[folder]/js/jquery-ui.min.js" ?>"></script>
<script src="<?php echo "$anekaweb/$f[folder]/js/bootstrap.js" ?>"></script>
<script src="<?php echo "$anekaweb/$f[folder]/js/jquery.easing.js" ?>"></script>
<script src="<?php echo "$anekaweb/$f[folder]/js/jquery.mousewheel.js" ?>"></script>
<script src="<?php echo "$anekaweb/$f[folder]/js/jquery.flexslider.js" ?>"></script>
<script src="<?php echo "$anekaweb/$f[folder]/js/jquery.elastislide.js" ?>"></script>
<script src="<?php echo "$anekaweb/$f[folder]/js/jquery.selectbox-0.2.js" ?>"></script>
<script src="<?php echo "$anekaweb/$f[folder]/js/jquery.nouislider.js" ?>"></script>
<script src="<?php echo "$anekaweb/$f[folder]/js/cloud-zoom.1.0.2.js" ?>"></script>
<script src="<?php echo "$anekaweb/$f[folder]/js/custom.js" ?>"></script>
   <script src="<?php echo "$anekaweb/$f[folder]/js/camera.min.js" ?>" type="text/javascript"></script>

<script src="<?php echo "$anekaweb/$f[folder]/js/scripts.js" ?>"></script>
<!-- ddsmoothmenu -->
<script src="<?php echo "$anekaweb/$f[folder]/js/ddsmoothmenu.js" ?>" type="text/javascript"></script>
<script src="<?php echo "$anekaweb/$f[folder]/js/menu.js" ?>" type="text/javascript"></script>

<!--[if lt IE 9]>
		<script type="text/javascript" src="js/html5.js"></script>
        <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
    <![endif]-->
 <script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/id_ID/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);}(document, 'script', 'facebook-jssdk'));</script>
  
  <!-- jRating -->
<link href="jRating/jRating.jquery.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="jRating/jRating.jquery.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
		$(".basic").jRating({
	  		isDisabled : true
    	});    
	});
</script>


 <script type="text/javascript">
function pad(n) { return (n < 10 ? '0' : '') + n;}
function updateWCTime(datetime,id) {
    now      = new Date();
    kickoff  = Date.parse(datetime);
    diff = kickoff - now;

    days  = Math.floor( diff / (1000*60*60*24) );
    hours = Math.floor( diff / (1000*60*60) );
    mins  = Math.floor( diff / (1000*60) );
    secs  = Math.floor( diff / 1000 );

    dd = days;
    hh = hours - days  * 24;
    mm = mins  - hours * 60;
    ss = secs  - mins  * 60;
	
	if(ss>=0 && mm>=0 && hh>=0 && dd>=0){
    $("#anekaweb_countdown_"+id)
            .html(
                '<div class="countdown_inner">' +
                '<div class="title">Waktu diskon produk ini:</div>' +
                '<div class="defaultCountdown-171 hasCountdown is-countdown">' +
                '<div class="countdown-row countdown-show4">' +
				'<span class="countdown-section"><span class="countdown-amount">' + pad(dd) + '</span><span class="countdown-period">Hari</span></span>' +
                '<span class="countdown-section"><span class="countdown-amount">' + pad(hh) + '</span><span class="countdown-period">Jam</span></span>' +
                '<span class="countdown-section"><span class="countdown-amount">' + pad(mm) + '</span><span class="countdown-period">Menit</span></span>' +
                '<span class="countdown-section"><span class="countdown-amount">' + pad(ss) + '</span><span class="countdown-period">Detik</span></span>' +
				'</div>' +
                '</div>' +
                '</div>'
				);
	}
	else {
		$("#anekaweb_countdown_"+id).fadeIn();
		  $.ajax({
			type: "POST",
			url: "../anekawebconfig/diskon_stok.php",
			data: "ajax=true&id_produk="+id,
			success: function(data)
			{
				$("#divharga"+id).html(data);
			}
		});
	}
	
	setTimeout(function(){
		updateWCTime(datetime,id);
	}, 1000);
}
</script> 
 <script type="text/javascript">
function pad(n) { return (n < 10 ? '0' : '') + n;}
function updateAnekaWebTime(datetime,id) {
    now      = new Date();
    kickoff  = Date.parse(datetime);
    diff = kickoff - now;

    days  = Math.floor( diff / (1000*60*60*24) );
    hours = Math.floor( diff / (1000*60*60) );
    mins  = Math.floor( diff / (1000*60) );
    secs  = Math.floor( diff / 1000 );

    dd = days;
    hh = hours - days  * 24;
    mm = mins  - hours * 60;
    ss = secs  - mins  * 60;
	
	if(ss>=0 && mm>=0 && hh>=0 && dd>=0){
    $("#anekaweb_countdown1_"+id)
            .html(
                '<div class="countdown_inner">' +
                '<div class="title">Waktu diskon produk ini:</div>' +
                '<div class="defaultCountdown-171 hasCountdown is-countdown">' +
                '<div class="countdown-row countdown-show4">' +
				'<span class="countdown-section"><span class="countdown-amount">' + pad(dd) + '</span><span class="countdown-period">Hari</span></span>' +
                '<span class="countdown-section"><span class="countdown-amount">' + pad(hh) + '</span><span class="countdown-period">Jam</span></span>' +
                '<span class="countdown-section"><span class="countdown-amount">' + pad(mm) + '</span><span class="countdown-period">Menit</span></span>' +
                '<span class="countdown-section"><span class="countdown-amount">' + pad(ss) + '</span><span class="countdown-period">Detik</span></span>' +
				'</div>' +
                '</div>' +
                '</div>'
				);
	}
	else {
		$("#anekaweb_countdown1_"+id).fadeIn();
		  $.ajax({
			type: "POST",
			url: "../anekawebconfig/diskon_stok.php",
			data: "ajax=true&id_produk="+id,
			success: function(data)
			{
				$("#divharga"+id).html(data);
			}
		});
	}
	
	setTimeout(function(){
		updateAnekaWebTime(datetime,id);
	}, 1000);
}
</script>

</head>
<body>
<div id="wrap">
  <div id="right_toolbar" class="hidden-phone hidden-tablet">
    <div id="back-top"> <a href="#top"><i class="icon-up-2"></i></a> </div>
  </div>
  
  <!--HEADER-->
    <div class="container">
  <div id="topline">
      <div class="wrapper_w">
        <?php include "akun.php";?>
      </div>
    </div>
    
    
    
     <div class="row">
        <div class="span12">
        
        <!-- mega menu start -->

<div class="Flat_mega_menu">

<i class="fa fa-bars"></i>
<input class="mobile_button" type="checkbox">

	    <ul>
    	
              <?php
			  function get_menu($data, $parent = 0) {
			  static $i = 1;
			  $tab = str_repeat(" ", $i);
			  if ($data[$parent]) {
			  $i++;
			  foreach ($data[$parent] as $v) {
			  $child = get_menu($data, $v->id_menu);
			  $html .= "$tab<li>";
			  $html .= '<a class="'.$css.'" href="'.$v->link.'">'.$v->nama_menu.'</a>';
			  if ($child) {
			  $i--;
			  $html .= "<ul class='submenu one_col'>$child";
			  $html .= "$tab</ul>";}
			  $html .= '</li>';}
			  return $html;}
			  else {
			  return false;}}
			  
			  $result = mysql_query("SELECT * FROM menu WHERE aktif='Y' ORDER BY id_menu");
			  while ($row = mysql_fetch_object($result)) {
			  $data[$row->id_parent][] = $row; }
			  $menu = get_menu($data);
			  echo "$menu";
			  ?>
          
          
    </ul>
</div>

<!-- mega menu end -->
            
        </div>
      </div>
      
      
    </div>
    
    
    <div class="container">
  <div id="header">
      <div class="wrapper_w">
      
        <div id="logo"> 
        	
        <?php
     $logo=mysql_query("SELECT * FROM logo ORDER BY id_logo");
      while($b=mysql_fetch_array($logo)){
echo "<a href='index.php'><img src='$anekaweb/images/logo/$b[gambar]' width='250' height='85' alt='$b[judul]'/></a> ";
	   }
	   ?></div>
        <div class="pull-right padding-1">
          <div class="shoppingcart">
         <?php require_once "anekawebconfig/item.php";?>
          </div>
        </div>
        <div class="pull-right padding-1">
          <div class="form-search-wrapper">
            <form action="hasil-pencarian.html" method="post" class="form-search" id="form-search">
              <input required id="kata" name="kata" type="text" class="search-query" value="pencarian..." onBlur="if (this.value == '') {this.value = 'pencarian...';}" onFocus="if(this.value == 'pencarian...') {this.value = '';}">
              <button type="submit" class="btn" onClick="document.getElementById('form-search').submit()"><i class="icon-search-2 icon-large"></i></button>
            </form>
            
          </div>
        </div>
      </div>
     
    </div>
  </div>
  
  
  <?php include "$f[folder]/konten.php";?>
  

  
<!--FOOTER-->
<div  id="footer">
  <div id="footer_line">
    <div class="container" id="footer_bottom">
      <div class="row">
        <div class="span12">
          <div class="pull-left noHover">
          
          <span class="text">&copy; <?=date("Y")?> <a href="anekaweb.com"><?php echo "$iden[nama_website]";?></a>. All Rights Reserved. </span></div>
          <?php
		$ip=$_SERVER['REMOTE_ADDR'];
		$tanggal=date("d-m-Y");
		$tgl=date("d");
		$bln=date("m");
		$thn=date("Y");
		$tglk=$tgl-1;
		$baca=mysql_query("SELECT * FROM konter WHERE ip='$sip' AND tanggal='$stgl' AND waktu='$sjam'");
		$baca1=mysql_num_rows($baca);
		if($baca1==0){
			$tkonter=mysql_query("INSERT INTO konter VALUES ('$sip','$stgl','$sjam')");
		}
			$q=mysql_query("SELECT * FROM konter");
			$blan=date("m-Y");
			$bulan=mysql_query("SELECT * FROM konter WHERE tanggal LIKE '%$blan%'");
			$tahunini=mysql_query("SELECT * FROM konter WHERE tanggal LIKE '%$thn%'");
			$today=mysql_query("SELECT * FROM konter WHERE tanggal='$tanggal'");
		    if($tglk=='1' | $tglk=='2' | $tglk=='3' | $tglk=='4' | $tglk=='5' | $tglk=='6' | $tglk=='7' | $tglk=='8' | $tglk=='9'){
		    $kemarin=mysql_query("SELECT * FROM konter WHERE tanggal='0$tglk-$bln-$thn'");
		    } else {
			$kemarin=mysql_query("SELECT * FROM konter WHERE tanggal='$tglk-$bln-$thn'");
			}
			$visitor = mysql_num_rows($q);
			$bulan1=mysql_num_rows($bulan);
			$tahunini1=mysql_num_rows($tahunini);
			$kemarin1 = mysql_num_rows($kemarin);
			$todays=mysql_num_rows($today);
		?>
          <div class="pull-right noHover">
          Online: <?php include "statistik/useronline.php"; ?> 
                                   | Hits: <?=$todays;?>/<?=$bulan1;?> Total <?=$visitor;?> 
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script language="JavaScript" type="text/javascript">
function refreshCaptcha()
{
	var img = document.images['captchaimg'];
	img.src = img.src.substring(0,img.src.lastIndexOf("?"))+"?rand="+Math.random()*1000;
}
</script>

 

</body>
</html>