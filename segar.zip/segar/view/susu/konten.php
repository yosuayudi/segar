<script language="javascript">
function validasi(form){
  if (form.nama.value == ""){
    alert("Anda belum mengisikan Nama.");
    form.nama.focus();
	return (false);
  }    
  else if (form.alamat.value == ""){
    alert("Anda belum mengisikan Alamat.");
    form.alamat.focus();
	return (false);
  }
  else if (form.telpon.value == ""){
    alert("Anda belum mengisikan Telpon.");
    form.telpon.focus();
	return (false);
  }
  else if (form.email.value == ""){
    alert("Anda belum mengisikan Email.");
    form.email.focus();
	return (false);
  }
  else if (form.kota.value == 0){
    alert("Anda belum mengisikan Kota.");
    form.kota.focus();
	return (false);
  }
  else if (form.kode.value == ""){
    alert("Anda belum mengisikan Kode.");
    form.kode.focus();
	return (false);
  }
  else if (form.username.value == ""){
    alert("Anda belum mengisikan Username.");
    form.username.focus();
	return (false);
  }
  else {
	return (true);
  }
function validasi2(form2){
  if (form2.username.value == ""){
    alert("Anda belum mengisikan Username.");
    form2.username.focus();
    return (false);
  }
  if (form2.password.value == ""){
    alert("Anda belum mengisikan Password.");
    form2.password.focus();
    return (false);
  }
  return (true);
}

function harusangka(jumlah){
  var karakter = (jumlah.which) ? jumlah.which : event.keyCode
  if (karakter > 31 && (karakter < 48 || karakter > 57))
    return false;

  return true;
}
</script>
<?php

switch($_GET[module]){
case "store":
	include "modul/beranda.php";
break;

case "detailproduk":
	include "modul/produk/detailproduk.php";
break;

case "detailkategori":
	include "modul/produk/detailkategori.php";
break;

case "pendaftaran":
	include "modul/daftar/register.php";
break;

case "daftar":
	include "modul/daftar/daftar.php";
break;

case "login":
	include "modul/daftar/login.php";
break;

case "lupapassword":
	include "modul/daftar/lupapassword.php";
break;

case "kirimpassword":
	include "modul/daftar/kirimpassword.php";
break;

case "semuaproduk":
	include "modul/produk/semuaproduk.php";
break;

case "lihatorder":
	include "member/lihat-order.php";
break;

case "semuablog":
	include "modul/blog/semuablog.php";
break;

case "detailblog":
	include "modul/blog/detailblog.php";
break;
case "detailkategoriblog":
	include "modul/blog/detailkategoriblog.php";
break;
case "keranjangbelanja":
	include "modul/produk/keranjangbelanja.php";
break;

case "halamanstatis":
	include "modul/halaman/halamanstatis.php";
break;

case "selesaibelanja":
	include "modul/produk/selesaibelanja.php";
break;

case "simpantransaksi":
	include "modul/produk/simpantransaksi.php";
break;

case "detailkategori":
	include "modul/produk/detailkategori.php";
break;

case "hasilcari":
	include "modul/produk/hasilcari.php";
break;

case "kontak":
	include "modul/hubungi/kontak.php";
break;

case "kontakaksi":
	include "modul/hubungi/kontakaksi.php";
break;
case "semuadownload":
	include "modul/halaman/katalog.php";
break;

case "testimonial":
	include "modul/testimonial/testimonial.php";
break;

case "testimonialaksi":
	include "modul/testimonial/testimonialaksi.php";
break;

case "profilkami":
	include "modul/halaman/profilkami.php";
break;

case "carapemesanan":
	include "modul/halaman/carapemesanan.php";
break;

case "notfound":
	include "modul/notfound/404.php";
break;

case "cekorder":
	include "modul/produk/cekorder.php";
break;

case "profil":
	include "member/modul/mod_profil/profil.php";
break;

case "lihatorder":
	include "member/lihat-order.php";
break;

case "tampilorder":
	include "member/modul/mod_tampil_order/tampil_order.php";
break;

}
?>