  <section id="content">
    <div class="container top">
       <?php
		if(isset($_SESSION[member_id])){
		$sql  = mysql_query("SELECT * FROM kustomer WHERE id_kustomer=$_SESSION[member_id]");
		$r    = mysql_fetch_array($sql);
		?>
					<div class="row">
        <div class="span12">
          <div class="wrapper">
            <h2 class="nopadding">Data Akun Anda Sebagai Berikut :</h2>
          </div>
        </div>
      </div>
					<?php
			  echo "<div class='box-wrapper'>
			        <div class='inside'>
                    <table class='table shopping-cart-table'>
      				<tr><td>Nama           </td><td>$r[nama_kustomer] </td></tr>
      				<tr><td>Alamat Lengkap </td><td>$r[alamat] </td></tr>
      				<tr><td>Telpon         </td><td>$r[telpon] </td></tr>
      				<tr><td>Kode Pos         </td><td>$r[kode_pos] </td></tr>
      				<tr><td>Propinsi         </td><td>$r[propinsi] </td></tr>
      				<tr><td>Kota         </td><td>$r[kota] </td></tr>
      				<tr><td>E-mail         </td><td>$r[email] </td></tr></table>
					<p>Barang yang dipesan akan dikirim sesuai alamat yang tertera diatas,
                       setelah anda melakukan konfirmasi pembayaran.</p><br/>
					   <a href='simpan-transaksi.html' class='button button-2x'><span>Proses pemesanan</span></a></b></p>
					   </table>
					   </div></div></div></div>";
					 
					?>
					<?php
					} else {
					?>
               
      <div class="row">
        <div class="span12">
          <div class="wrapper">
            <h2 class="nopadding">Login atau buat akun baru</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="span6">
          <div class="box-wrapper">
            <div class="inside min-height">
              <h4>PELANGGAN BARU</h4>
              <p>Dengan membuat akun di toko kami, Anda dapat melakukan proses belanja cepat, menyimpan beberapa alamat pengiriman dan mengetahui proses pengiriman produk serta banyak kemudahan lainnya. Anda dipersilakan untuk mendaftar akun sebagai pelanggan baru di toko kami! </p>
            </div>
            <div class="line"></div>
            <div class="inside">
              <div class="wrapper">
                <div class="pull-right"><a href="daftar.html" class="button button-2x dark">Daftar</a></div>
              </div>
            </div>
          </div>
        </div>
        <div class="span6">
          <div class="box-wrapper">
            <div class="inside min-height">
              <h4>PELANGGAN TERDAFTAR</h4>
              <p>Apabila anda sudah memiliki akun silakan login.</p>
              <form action="member/cek_login.php" method="post" lass="margin-2" name="form2" onSubmit=\"return validasi2(this)\">
                <p>Username *</p>
                <input type="text" name="username" id="textfield" class="input-xlarge">
                <p>Password *</p>
                <input type="password" name="password" id="textfield2" class="input-xlarge">
            </div>
            <div class="line"></div>
            <div class="inside">
              <div class="wrapper">
                <div class="pull-left margin-2"><a href="lupa-password.html" class="custom_color">Lupa Password?</a></div>
                <div class="pull-right"><input type="submit" class="button" value="Login" /></div>
              </div>
            </div>
               </form>
               
          </div>
        </div>
      </div>
    </div>
  </section>
  <div id="push"></div>
</div>
<?php
}
?>