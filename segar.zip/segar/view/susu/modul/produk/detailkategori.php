      <section id="content">
      <div class="container top">
      <div class="content_top">
      <div class="breadcrumbs"><?php include "anekawebconfig/breadcrumb.php"; ?></div>
      </div>
      <div class="row">
      <div class="span9" id="column_right">
       <?php
      // Tampilkan nama kategori
	  $sq = mysql_query("SELECT nama_kategori from kategoriproduk WHERE id_kategori='$_GET[id]'");
	  $n = mysql_fetch_array($sq);
echo "<h2>$n[nama_kategori]</h2>";?>

      <div class="line1"></div>
      <div class="listing_header_row1">

      <?php
      // Tentukan berapa data yang akan ditampilkan per halaman (paging)
      $p      = new Pagination1("media.php?module=detailkategori&id=".abs((int)$_GET['id']));
      $batas  = isset($_GET['perpage']) ? abs((int)$_GET['perpage']) : 20;
      $posisi = $p->cariPosisi($batas);
      $order_by = isset($_GET['order_by']) ? strip_tags($_GET['order_by']) : 'terbaru';
      $order_array = array('terbaru' => 'id_produk', 'terlaris' => 'dibeli', 'abjad' => 'nama_produk', 'diskon' => 'diskon');
    
      // Tampilkan semua produk
      $sql=mysql_query("SELECT * FROM produk WHERE id_kategori='$_GET[id]' ORDER BY ".$order_array[$order_by]." DESC LIMIT $posisi,$batas");
	  
      $order_combo = array(
	  'terbaru' => 'Terbaru',
      'terlaris' => 'Terlaris',
      'abjad' => 'Abjad',
      'diskon' => 'Diskon');
      $perpage_combo = array(20,50,80,100);
        
echo '<div class="pull-left">
	  <label>Sort by:</label>
	  <div class="select_wrapper width1">
	  <form action="media.php" method="get">
	  <input type="hidden" name="module" value="detailkategori">
		<input type="hidden" name="id" value="'.abs((int)$_GET['id']).'">
	  <select name="order_by" class="custom" tabindex="1" onchange="this.form.submit()">';
	  foreach($order_combo as $key => $val){
	  $selected = $key==$order_by ? 'selected' : '';
echo '<option value="'.$key.'" '.$selected.'>'.$val.'</option>';
	  }
echo '</select>
      </div>
      </div>
      <div class="pull-right alignright">
      <label><span class="hidden-phone">Show:</span></label>
      <div class="select_wrapper width2">
      <select name="perpage" class="custom" tabindex="1" onchange="this.form.submit()">';
      foreach($perpage_combo as $perpage){
      $selected = $perpage==$batas ? 'selected' : '';
echo '<option value="'.$perpage.'" '.$selected.'>'.$perpage.'</option>';
        }
echo '</select>
      </form>';
echo '</div>
      per&nbsp;page</div>
      </div>
      <div class="line1"></div>
      <div class="listing_header_row2">
      <div class="pull-right">';
    
	  $jmldata     = mysql_num_rows(mysql_query("SELECT * FROM produk WHERE id_kategori='$_GET[id]'"));
	  $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
	  $linkHalaman = $p->navHalaman($_GET[page], $jmlhalaman);
	  
echo "<div class='num'> $linkHalaman</div>
      </div>
      </div>";
	  ?>
	 
      <div class="row big_with_description">
	  <?php
      while ($r=mysql_fetch_array($sql)){
      include "anekawebconfig/diskon_stok.php";
      $harga = number_format($r[harga],0,",",".");
      ?>
                <div class="span3 product">
                <div class="product-image-wrapper">
                <div class="anekaweb-crop">
               <?php echo "<a href='produk-$r[id_produk]-$r[produk_seo].html'>
			               <img src='$anekaweb/images/produk/$r[gambar]' alt='$r[nama_produk]' width='229'>
                           <img src='$anekaweb/images/produk/$r[gambar]' class='roll_over_img' alt='$r[nama_produk]'></a>";?>
                   <?php echo "<div id='anekaweb_countdown_".$r['id_produk']."' class='countdown_box'>
                <script>updateWCTime('".date('F d, Y H:i:s',$r['diskon_expired'])."',$r[id_produk]);</script>
                </div>";?>         
                
                </div>
                </div>
                <div class="wrapper-hover">
                  <div class="product-name"> <?php echo "<a href='produk-$r[id_produk]-$r[produk_seo].html'>$r[nama_produk]</a>";?></div>
                  <div class="wrapper">
                  <?php echo"<div class='product-price' id='divharga".$r['id_produk']."'>$divharga</div>";?>
                   
                    
                  </div>
                </div>
              </div>
              
                 <?php } ?>
          </div>
         <div class="line1"></div>
      <div class="listing_header_row1">
       <div class="pull-left">
	  <label>Sort by:</label>
	  <div class="select_wrapper width1">
      <?php 
echo '<form action="media.php" method="get">
	  <input type="hidden" name="module" value="detailkategori">
	  <input type="hidden" name="id" value="'.abs((int)$_GET['id']).'">
	  <select name="order_by" class="custom" tabindex="1" onchange="this.form.submit()">';
	  foreach($order_combo as $key => $val){
	  $selected = $key==$order_by ? 'selected' : '';
echo '<option value="'.$key.'" '.$selected.'>'.$val.'</option>';
	  }
echo '</select>
      </div>
      </div>
      <div class="pull-right alignright">
      <label><span class="hidden-phone">Show:</span></label>
      <div class="select_wrapper width2">
      <select name="perpage" class="custom" tabindex="1" onchange="this.form.submit()">';
      foreach($perpage_combo as $perpage){
      $selected = $perpage==$batas ? 'selected' : '';
echo '<option value="'.$perpage.'" '.$selected.'>'.$perpage.'</option>';
        }
echo '</select>
      </form>';
echo '</div>
      per&nbsp;page</div>
      </div>
      <div class="line1"></div>
      <div class="listing_header_row2">
      <div class="pull-right">';
    
	  $jmldata     = mysql_num_rows(mysql_query("SELECT * FROM produk WHERE id_kategori='$_GET[id]'"));
	  $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
	  $linkHalaman = $p->navHalaman($_GET[page], $jmlhalaman);
	  
echo "<div class='num'> $linkHalaman</div>
      </div>
      </div>
      </div>";
      ?>
      <?php include "$f[folder]/modul//sidebar/sidebar.php";?>
      </div>
      </div> 
      </div>
      </section>
      
      
        
          </div>
          </div>