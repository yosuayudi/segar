<?php
	  if(isset($_POST[kata])){
  // menghilangkan spasi di kiri dan kanannya
  $kata = trim($_POST['kata']);
  // mencegah XSS
  $kata = htmlentities(htmlspecialchars($kata), ENT_QUOTES);

  // pisahkan kata per kalimat lalu hitung jumlah kata
  $pisah_kata = explode(" ",$kata);
  $jml_katakan = (integer)count($pisah_kata);
  $jml_kata = $jml_katakan-1;
	
  $cari = "SELECT * FROM produk WHERE " ;
    for ($i=0; $i<=$jml_kata; $i++){
      $cari .= "nama_produk LIKE '%$pisah_kata[$i]%'";
      if ($i < $jml_kata ){
        $cari .= " OR ";
      }
    }
  $cari .= " ORDER BY id_produk DESC LIMIT 8";
  $hasil  = mysql_query($cari);
  $ketemu = mysql_num_rows($hasil);
} else {
  $ketemu = 0;
}

echo "<section id='content'>
      <div class='container top'>
      <div class='row'>
      <div class='span9' id='column_right'>
      <h2>Hasil Pencarian</h2>";
	  
echo "Ditemukan <b>$ketemu</b> produk dengan kata <font style='background-color:#00FFFF'><b>$kata</b></font> :

     <div class='line'></div>"; 

      $no=1;
      while($r=mysql_fetch_array($hasil)){
		include "anekawebconfig/diskon_stok2.php";
		$harga = number_format($r[harga],0,",",".");
      // Tampilkan hanya sebagian isi produk
      $isi_produk = htmlentities(strip_tags($r['deskripsi'])); // mengabaikan tag html
      $isi_produk = substr($isi_produk,0,400); // ambil sebanyak 250 karakter
      $isi_produk = substr($isi_produk,0,strrpos($isi_produk," ")); // potong per spasi kalimat
	  
echo "<div class='row product-listing'>
      <div class='span3 product'>
      <div class='product-image-wrapper'>
	  
      <a href='product_normal_preview.html'><img src='images/produk/$r[gambar]' alt='$r[nama_produk]'>
	  <img src='images/produk/$r[gambar]' class='roll_over_img' alt='$r[nama_produk]'></a> 
	  </div>
      </div>
	  
	  
            <div class='span6 product-detailes'>
              <div class='product-name bottom-line'><a href='produk-$r[id_produk]-$r[produk_seo].html'><b>$r[nama_produk]</b></a></div>
              <div class='bottom-line'>
                <div class='price-box'> $divharga</div>
              </div>
              <div class='bottom-line'>$isi_produk...</div>
            </div>
          </div>
		  <div class='line'></div>";  
		  }
          
          
 ?>     </div>   
    <?php include "$f[folder]/modul/sidebar/sidebar.php";?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <div id="push"></div>