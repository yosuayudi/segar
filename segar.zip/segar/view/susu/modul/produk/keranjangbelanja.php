<?php

echo "<section id='content'>
      <div class='container top'>
	  <div class='wrapper_w'>
      <div class='pull-left'>
      <div class='breadcrumbs'>";
      include "anekawebconfig/breadcrumb.php";
echo "</div>
      </div>
      </div>
      <div class='row'>
      <div class='span12'>
      <div class='wrapper'>
      <h2 class='pull-left'>Keranjang Belanja</h2>
      <div class='pull-right right-button'><a href='semua-produk.html' class='button button-2x'>Lanjutkan Belanja</a></div>
      </div>
      <div class='box-wrapper'>
      <div class='inside'>";
	  
	  // Tampilkan produk-produk yang telah dimasukkan ke keranjang belanja
	  $sid = session_id();
	  $sql = mysql_query("SELECT * FROM orders_temp, produk 
	  WHERE id_session='$sid' AND orders_temp.id_produk=produk.id_produk");
	  $ketemu=mysql_num_rows($sql);
	  if($ketemu < 1){
echo "<script>window.alert('Keranjang Belanja Kosong');
	  window.location=('index.php')</script>";
	  }
	  else{
	  
echo "<form action='aksi.php?module=keranjang&act=update' id='anekaweb-simpan' method='post'>
      <table class='table shopping-cart-table'>
	  <tr>
	  <th>&nbsp;</th>
	  <th><strong>Nama Produk</strong></th>
	  <th class='aligncenter'><strong>Ukuran</strong></th>
	  <th class='aligncenter'><strong>Warna</strong></th>
	  <th class='aligncenter'><strong>Berat</strong></th>
	  <th class='aligncenter'><strong>Quantity</strong></th>
	  <th class='aligncenter'><strong>Harga</strong></th>
	  <th class='aligncenter'><strong>Sub Total</strong></th>
	  <th class='aligncenter'><strong>Hapus</strong></th>
	  </tr>";
	  
	  $no=1;
	  while($r=mysql_fetch_array($sql)){
	
	  $disc        = ($r[diskon]/100)*$r[harga];
	  $hargadisc   = number_format(($r[harga]-$disc),0,",",".");
	  $subtotal    = ($r[harga]-$disc) * $r[jumlah];
	  $total       = $total + $subtotal;  
	  $subtotal_rp =  number_format(($subtotal),0,",",".");
	  $total_rp    =  number_format(($total),0,",",".");
	  $harga       =  number_format(($r[harga]),0,",",".");
				
echo "<tr><input type=hidden name=id[$no] value=$r[id_orders_temp]>
      <td><img src='$anekaweb/images/produk/small_$r[gambar]' height='30' alt='$r[nama_produk]'></td>
      <td><span class='cart-col-name'></span><strong> <a href='produk-$r[id_produk]-$r[produk_seo].html'>$r[nama_produk]</a></strong></td>";
				  
	  $ket=str_replace("Ukuran -> ","",$r[keterangan_temp]);
	  $ket=str_replace("Warna -> ","",$ket);
	  $ket=str_replace("<br>","",$ket);
	  $opsi=explode(" ",$ket);
	  
echo "<td class='aligncenter'><strong> $opsi[0]</strong></td>
	  <td class='aligncenter'><strong> $opsi[2]</strong></td>
	  <td class='aligncenter'><strong>$r[berat]/kg</strong></td>
	  <td class='aligncenter'><span class='cart-col-name'></span>";
echo "<select name='jml[$no]' value=$r[jumlah] onChange='this.form.submit()'>";
	  for ($j=1;$j <= $r[stok];$j++){
	  if($j == $r[jumlah]){
echo "<option selected>$j</option>";
      }else{
echo "<option>$j</option>";
      }
        }
echo "</select></td>
      <td class='aligncenter'><span class='cart-col-name'></span><strong>Rp. $hargadisc</strong></td>
      <td class='aligncenter'><span class='cart-col-name'></span><strong>Rp. $subtotal_rp</strong></td>
      <td class='aligncenter'><a href='aksi.php?module=keranjang&act=hapus&id=$r[id_orders_temp]' class='icon-trash-2 custom_color'></a></a></td>
      </tr>";
	  $no++; 
	  }
	
echo "</form>
      </table>";
			  
echo "<form method=post action=selesai-belanja.html>	  
      <div class='row'>
      <div class='pull-left'>
	  <div class='span7'>
      <div class='box-wrapper'>
	  <div class='inside'>
	  <h2>Keterangan Belanja</h2>
	  <p>Total harga belum termasuk ongkos kirim yang akan di hitung saat selesai belanja. </p>
	
      </div>
      </div>
      </div>
	  </div>
		
	
	  
	  <div class='span-anekaweb1'>
	  <div class='box-wrapper'>
	  <div class='inside'>
	  <table class='table shopping-cart-table-total'>
	  <tr>
	  <th class='alignright'>Subtotal</th>
	  <th> Rp. $total_rp</th>
	  </tr>
	  <tr>
	  <td class='alignright'><h4>GRAND TOTAL</h4></td>
	  <td><h4>Rp. $total_rp</h4></td>
	  </tr>
	  </table>
	  <div class='aligncenter'>
	  <input type='submit' class='button' value='Selesai Belanja'>
	  </div>
	  </div>
	  </div>
	
	  </div>
	  </div>
	  </div>
	  </div>
	  </div>
      
	  
	  </div>
	  </div>
	  </div>
	  </div>
	  </section>
	  <div id='push'></div>
	  </div>"; 
	  
	   }
?>