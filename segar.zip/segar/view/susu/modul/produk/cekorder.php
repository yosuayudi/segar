<section id="content">
  <div class="container top">
   <div class="content_top">
      <div class="breadcrumbs">
      <?php include "anekawebconfig/breadcrumb.php"; ?></div>
       
      </div>
    <div class="row">
      <div class="span9" id="column_right">
  <h3>Cek Order</h3>
  <?php 
	   // menghilangkan spasi di kiri dan kanannya
				  $cek = trim($_POST['cek']);
				  // mencegah XSS
				  $cek = htmlentities(htmlspecialchars($cek), ENT_QUOTES);

				 
				  $hasil  = mysql_query("SELECT * FROM orders,kustomer
				                                  WHERE orders.id_kustomer=kustomer.id_kustomer 
										          ORDER BY id_orders='$cek'");
				  $ketemu = mysql_num_rows($hasil);
				  $r= mysql_fetch_array($hasil);

				  if ($ketemu == 1){
				  echo "<p>Status Order Anda    : <b>$r[status_order]</b></p>";
					if ($r[status_order] == 'Dikirim'){
						echo "<p> Dengan Nomor Resi : <b>$r[resi]</b></p>";
						}
					else{
					echo"";
					}
				  echo "<table class='table shopping-cart-table'>
						<tr><td>Nama Kustomer</td><td> $r[nama_kustomer]</td></tr>
						<tr><td>Alamat Pengiriman</td><td> $r[alamat]</td></tr>
						<tr><td>No. Telpon/HP</td><td> $r[telpon]</td></tr>
						<tr><td>Email</td><td> $r[email]</td></tr>
						</table>";        
					}                                                          
				  else{
					echo "<p>Tidak ditemukan ID ORDER <b>$cek</b> Silahkan Cek email anda</p>";
				  }
				  ?>
		
       </div>		
    <?php include "$f[folder]/modul/sidebar/sidebar.php";?>
        </div>
      </div>
    </div>
  </section>
  <div id="push"></div>
</div>
