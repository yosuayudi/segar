<section id="content">
<div class="container top">
<div class="row">

<?php
$bank=mysql_fetch_array(mysql_query("SELECT * FROM mod_bank"));
$iden=mysql_fetch_array(mysql_query("SELECT * FROM identitas"));
$logo=mysql_fetch_array(mysql_query("SELECT * FROM logo"));

$kar1=strstr($_POST[email], "@");
$kar2=strstr($_POST[email], ".");

if (!isset($_SESSION[member_id])){          
  echo "<div class='order-id'><br><br>Silahkan login terlebih dahulu<br />
  	    <a href='selesai-belanja.html'><b>Silahkan Login</b><br><br></div>";
} else {
?>
						
<div class="aligncenter">
<div class="button button-3x"><i class="icon-comment"></i></div>
<p style="font-size:24px;line-height:24px;">Terima kasih telah berbelanja di <strong><?php echo $iden[nama_website];?></strong></p>

						
<?php
// fungsi untuk mendapatkan isi keranjang belanja
function isi_keranjang(){
	$isikeranjang = array();
	$sid = session_id();
	$sql = mysql_query("SELECT * FROM orders_temp WHERE id_session='$sid'");
	
	while ($r=mysql_fetch_array($sql)) {
		$isikeranjang[] = $r;
	}
	return $isikeranjang;
}

$tgl_skrg = date("Ymd");
$jam_skrg = date("H:i:s");

function antiinjection($data){
  $filter_sql = mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
  return $filter_sql;
}

$k=mysql_fetch_array(mysql_query("SELECT * FROM kustomer WHERE id_kustomer=$_SESSION[member_id]"));
$nama   = $k['nama_kustomer'];
$alamat = $k['alamat'];
$telpon = $k['telpon'];
$email = $k['email'];
$kode_pos = $k['kode_pos'];
$propinsi = $k['propinsi'];
$kota = $k['kota'];

// simpan data pemesanan 
mysql_query("INSERT INTO orders(id_kustomer, tgl_order, jam_order, alamat, kode_pos, propinsi, kota) 
             VALUES('$_SESSION[member_id]','$tgl_skrg','$jam_skrg','$alamat','$kode_pos','$propinsi','$kota')");
			 
  
// mendapatkan nomor orders
$id_orders=mysql_insert_id();

echo "<p style='font-size:18px;'>ID order Anda adalah: <strong>#$id_orders</strong></p>
      </div></div><br/>";

// panggil fungsi isi_keranjang dan hitung jumlah produk yang dipesan
$isikeranjang = isi_keranjang();
$jml          = count($isikeranjang);



// simpan data detail pemesanan  
for ($i = 0; $i < $jml; $i++){
  $keterangan="{$isikeranjang[$i]['keterangan_temp']}";
  mysql_query("INSERT INTO orders_detail(id_orders, id_produk, jumlah, keterangan) 
               VALUES('$id_orders',{$isikeranjang[$i]['id_produk']}, {$isikeranjang[$i]['jumlah']}, '$keterangan')");
}
 
//dapatkan no orders untuk detail order dan afiliasi
		$sql=mysql_query("SELECT * FROM orders WHERE id_kustomer='$_SESSION[member_id]' AND status_order='Baru' ORDER BY id_orders DESC");
		$r=mysql_fetch_array($sql);
 
// setelah data pemesanan tersimpan, hapus data pemesanan di tabel pemesanan sementara (orders_temp)
for ($i = 0; $i < $jml; $i++) {
  mysql_query("DELETE FROM orders_temp
	  	         WHERE id_orders_temp = {$isikeranjang[$i]['id_orders_temp']}");
}

echo "<div class='row'>
      <div class='span12'>
      <div class='wrapper'>
      <h2 class='nopadding'>Data beserta order anda sebagai berikut :</h2>
      </div>
	  <div class='box-wrapper'> 
	  <div class='inside'>
      <table class='table shopping-cart-table'>
      <tr>
	  <td>Nama</td>
	  <td><b>$nama</b></td>
	  </tr>
      <tr>
	  <td>Alamat </td>
	  <td>$alamat </td>
	  </tr>
      <tr>
	  <td>Telpon</td>
	  <td>$telpon</td>
	  </tr>
      <tr>
	  <td>Kode Pos</td>
	  <td>$kode_pos</td>
	  </tr>
	  <td>Propinsi</td>
	  <td>$propinsi</td>
	  </tr>
      <tr>
	  <td>Kota</td>
	  <td>$kota</td>
	  </tr>
      <tr>
	  <td>E-mail</td>
	  <td>$email</td>
	  </tr>
      <tr>
	  </table>
	  </div>
	  </div>
	  </div>
	  </div>";

      $daftarproduk=mysql_query("SELECT * FROM orders_detail,produk 
                                 WHERE orders_detail.id_produk=produk.id_produk 
                                 AND id_orders='$id_orders'");

echo "<div class='row'>
      <div class='span12'>
	  <div class='box-wrapper'> 
	  <div class='inside'>
      <table class='table shopping-cart-table'>
	  <tr>
	  <th>&nbsp;</th>
	  <th><strong>Nama Produk</strong></th>
	  <th class='aligncenter'><strong>Berat</strong></th>
	  <th class='aligncenter'><strong>Quantity</strong></th>
	  <th class='aligncenter'><strong>Keterangan</strong></th>
	  <th class='aligncenter'><strong>Harga</strong></th>
	  <th class='aligncenter'><strong>Sub Total</strong></th>
	  </tr>";
      
// Kirim Email /////////////////////////////////////////////////////////////////   
$pesan="<table width='600' border='0' cellspacing='0' cellpadding='0'>
		<tbody>
		<tr>
		<td width='250'><p><strong><b>Kantor $iden[nama_website]:</b></strong><br>
		<span class=\"color:#896173;font-size:12px;\">$iden[alamat]</p>
		</td>
		
		<td>&nbsp;</td>
		<td width='147'><a href='$iden[url]' target='_blank'>
		<img src='$iden[url]/images/logo/$logo[gambar]' width='194' height='68'><a/></td>
		</tr>
		</tbody>
		</table>
		<br/>
		
		<table width='600' border='0' cellspacing='0' cellpadding='0'>
		<tbody>
		<tr bgcolor='#0a9bf7'>
        <td  width='600' height='30' style='font-size: 13px; color:#FFFFFF; text-align:left; padding-left:10px;'>
        Terimakasih telah melakukan pemesanan online di <b>$iden[nama_website]</b></td>
        </tr>
		</tbody>
		</table>
		
		
		<table border='0' cellpadding='0' cellspacing='0' width='600' style='font-size:13px; color: #000000; 
  background-color:#FFFFFF; margin-top:2px; margin-bottom:2px;'>
       <tbody>
		
		<tr bgcolor='#f0f0f0'>
        <td style='text-align:left; padding-left:10px;'>No. Order</td>
        <td width='350' height='20'>: <b>$id_orders</b></td>
        </tr>
		  
		<tr bgcolor='#ffffff'>
        <td style='text-align:left; padding-left:10px;'>Nama</td>
        <td width='350' height='20'>: $nama</td>
        </tr> 
		 
		<tr bgcolor='#f0f0f0'>
        <td style='text-align:left; padding-left:10px;'>Alamat</td>
        <td width='350' height='20'>: $alamat</td>
        </tr>
		 
		<tr bgcolor='#ffffff'>
        <td style='text-align:left; padding-left:10px;'>Telpon/HP</td>
        <td width='350' height='20'>: $telpon</td>
        </tr> 
		</tbody>
        </table>
		
		
		<table border='0' cellpadding='0' cellspacing='0' width='600'>
		<tbody>
		<tr bgcolor='#0a9bf7'>
        <td  width='600' height='30' style='font-size: 13px; color:#FFFFFF; text-align:left; padding-left:10px;'>
        Data order Anda adalah sebagai berikut:</td>
        </tr>
		</tbody>
        </table>
		
		<table border='0' cellpadding='0' cellspacing='0' 
		width='600' style='font-size:13px; color: #000000; background-color:#FFFFFF; margin-top:2px; margin-bottom:2px;'>
  <thead>
        
		<tr>
		<td width='20' height='30' bgcolor='#efefef'>
		<div align='center' class=\"color:#896173;font-size:14px;\"><b>No.</b></div></td>
		<td width='80' height='30' bgcolor='#efefef'>
		<div align='center' class=\"color:#896173;font-size:14px;\"><b>Nama Produk</b></div></td>
		<td width='40' height='30' bgcolor='#efefef'>
		<div align='center' class=\"color:#896173;font-size:14px;\"><b>Berat</b></div></td>
		<td width='50' height='30' bgcolor='#efefef'>
		<div align='center' class=\"color:#896173;font-size:14px;\"><b>Keterangan</b></div></td>
		<td width='80' height='30' bgcolor='#efefef'>
		<div align='center' class=\"color:#896173;font-size:14px;\"><b>Harga</b></div></td>
		<td width='80' height='30' bgcolor='#efefef'>
		<div align='center' class=\"color:#896173;font-size:14px;\"><b>Subtotal</b></div></td>
		</tr>
		<thead>
        </table>";
////////////////////////////////////////////////////////////////////////////////////////////////////////        
	    $no=1;
		while ($d=mysql_fetch_array($daftarproduk)){
        $n = mysql_fetch_array(mysql_query("SELECT * FROM produk WHERE id_produk=$d[id_produk]"));
	    $disc        = ($d[diskon]/100)*$d[harga];
	    $hargadisc   = number_format(($d[harga]-$disc),0,",","."); 
	    $subtotal    = ($d[harga]-$disc) * $d[jumlah];
	
	    $subtotalberat = $d[berat] * $d[jumlah]; // total berat per item produk 
	    $totalberat  = $totalberat + $subtotalberat; // grand total berat all produk yang dibeli
	    $total       = $total + $subtotal;
	    $subtotal_rp = format_rupiah($subtotal);    
	    $total_rp    = format_rupiah($total);    
	    $harga       = format_rupiah($d[harga]);
		

echo "<tr>
      <td><img src='images/produk/small_$d[gambar]' height='30' alt='$d[nama_produk]'></td>
      <td><span class='cart-col-name'></span><strong> <a href='produk-$d[id_produk]-$d[produk_seo].html'>$d[nama_produk]</a></strong></td>
	  <td class='aligncenter'><strong>$d[berat]/kg</strong></td>
      <td class='aligncenter'><strong>$d[jumlah]</strong></td>
      <td class='aligncenter'><span class='cart-col-name'></span><strong>$keterangan</strong></td>
      <td class='aligncenter'><span class='cart-col-name'></span><strong>Rp. $hargadisc</strong></td>
      <td class='aligncenter'><span class='cart-col-name'></span><strong>Rp. $subtotal_rp</strong></td>
      </tr>";
		}
echo " </table>";

// Kirim Email /////////////////////////////////////////////////////////////////  

$pesan.="<table border='0' cellpadding='0' cellspacing='0' width='600'>
		<tr>
		<td width='20' height='30'><center>$no</center></td>
		<td width='80' height='30'><center>$n[nama_produk]</center></td>
		<td width='40' height='30'><center>$n[berat]/kg</center></td>
		<td width='50' height='30'><center>$keterangan</center></td>
		<td width='80' height='30'><center>Rp. $hargadisc,-</center></td>
		<td width='80' height='30'><center>Rp. $subtotal_rp,-</center></td>
		</tr>
		</table>";
		
		$no++;
		}  
		$ongkos=mysql_fetch_array(mysql_query("SELECT ongkos_kirim FROM kota WHERE nama_kota='$kota'"));
		
		
		$ongkoskirim1=$ongkos[ongkos_kirim];
		$totalberat = ceil($totalberat);
		$ongkoskirim = $ongkoskirim1 * $totalberat;
		
		$grandtotal    = $total + $ongkoskirim; 
		
		$ongkoskirim_rp = format_rupiah($ongkoskirim);
		$ongkoskirim1_rp = format_rupiah($ongkoskirim1); 
		$grandtotal_rp  = format_rupiah($grandtotal);  
 

$pesan.="
        <table border='0' cellpadding='0' cellspacing='0' width='600'>
        <tr>
		<td width='350' height='25' colspan='5' bgcolor='#efefef'><div align='right'>Total: </div></td>
		<td bgcolor='#efefef'><div align='center'>Rp. $total_rp,-</div></td>
		</tr>";
		if($totalberat!=0){ 
$pesan.= "
        <tr>
		<td width='350' height='25' colspan='5'><div align='right'>Ongkos Kirim Tujuan Kota Pembeli: </div></td>
		<td><div align='center'>Rp. $ongkoskirim1_rp,- /Kg</div></td>
		</tr>
		<tr>
		<td width='350' height='25' colspan='5' bgcolor='#efefef'><div align='right'>Total Berat Barang: </div></td>
		<td bgcolor='#efefef'><div align='center'>$totalberat /Kg</div></td>
		</tr>
		<tr>
		<td width='350' height='25' colspan='5'><div align='right'>Ongkos Kirim: </div></td>
		<td><div align='center'>Rp. $ongkoskirim_rp,-</div></td>
		</tr>";
		}
$pesan.="
		<tr>
		<td width='350' height='25' colspan='5' bgcolor='#efefef'><div align='right'><b>Grand Total: </b></div></td>
		<td bgcolor='#efefef'><div align='center'><b>Rp. $grandtotal_rp,-</b></div></td>
		</tr>
		</table>
		
		
		<table width='600' style='font-size:12px; color: #fff; background-color:#0a9bf7; padding:10px;'>
		</tbody>
		<tr>
		<td width='30'>1.</td>
		<td>Apabila Ongkos Kirim nilainya Rp. 0 maka ongkos kirim akan dihitung secara manual. Konfirmasi kepada Kami via SMS ke HP. <b>$iden[no_telp]</b> untuk menentukan ongkos kirimnya.</td>
		</tr>
		
		<tr>
		<td width='30'>2.</td>
		<td>
		Apabila Ongkos Kirim tercantum, Silahkan lakukan pembayaran ke <b>Bank $bank[nama_bank]</b> sebanyak Grand Total yang tercantum, nomor rekeningnya 
	    <b>$bank[no_rekening] - $bank[pemilik]</b></td>
		</tr>
		</tbody>
        </table>";
		
		$kepada   = $k['email'];
		$subjek=".:: Pemesanan Online $iden[nama_website] ::.";
		
		// Kirim email dalam format HTML
		$dari = "From: $iden[nama_website] <".$iden[email].">\n";
		$dari .= "Content-type: text/html \r\n";
		
		// Kirim email ke kustomer
		//mail($kepada,$subjek,$pesan,$dari);
		
		// Kirim email ke pengelola toko online
		//mail("$iden[email] ",$subjek,$pesan,$dari);
        
		include "library/class.phpmailer.php";
$mail = new PHPMailer; 
$mail->IsSMTP();
$mail->Host = 'anekaweb.com'; //hostname masing-masing provider email 
$mail->SMTPDebug = 1;
$mail->Port = 25;
$mail->SMTPAuth = true;
$mail->Username = 'info@anekaweb.com'; //user email 
$mail->Password = '1nf02016W3b'; //password email 
$mail->SetFrom('info@anekaweb.com', $iden[nama_website]); //set email pengirim
$mail->Subject = $subject; //subyek email 
$mail->AddAddress($kepada, ' '); //tujuan email
$mail->MsgHTML($pesan);
$mail->Send();

echo "<div class='row'>
      <div class='span-anekaweb1'>
      <div class='pull-left'>
	  <div class='box-wrapper'>
	  <div class='inside'>
      <p>Data order dan nomor rekening transfer sudah terkirim ke email Anda. <br />
      Apabila Anda tidak melakukan pembayaran dalam 3 hari, maka transaksi dianggap batal.</p><br />   <br />
	  </div>
	  </div>
	  </div>   
	  </div> 
	  
	  
      <div class='pull-right hidden-phone'>
      <div class='span-anekaweb1'>
	  <div class='box-wrapper'>
	  <div class='inside'>
	  <table class='table shopping-cart-table-total'>
	  <tr>
	  <th class='alignright'>Total :</th>
	  <th> Rp. $total_rp</th>
	  </tr>
	  <tr>";
	  if($totalberat!=0){ 
echo "<th class='alignright'>Ongkos Kirim Tujuan Kota Anda :</th>
	  <th> Rp. $ongkoskirim1_rp</th>
	  </tr>
	  <tr>
	  <th class='alignright'>Total Berat :</th>
	  <th>$totalberat/Kg</th>
	  </tr>
	  <tr>
	  <th class='alignright'>Total Ongkos Kirim :</th>
	  <th>Rp. $ongkoskirim_rp</th>
	  </tr>";
	  }
echo "<tr>
	  <td class='alignright'><h4>GRAND TOTAL :</h4></td>
	  <td><h4>Rp. $grandtotal_rp</h4></td>
	  </tr>
	  </table>
	  </div>
	  </div>
	  </div>
	  </div>
	  </div>
  
      <a href='media.php?module=tampilorder&act=konfirmasi&id=$r[id_orders]' class='button button-2x'><span>Konfirmasi Pembayaran</span></a><br/><br/>
      
	  
	  </div>";
                
      ?>

	</div>
      </div>
      </div>
</div>
      </div>
			<section>