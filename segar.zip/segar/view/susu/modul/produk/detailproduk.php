   <?php
  // Tampilkan detail produk berdasarkan produk yang dipilih
	$detail=mysql_query("SELECT * FROM produk,kategoriproduk    
                      WHERE kategoriproduk.id_kategori=produk.id_kategori 
                      AND id_produk='".$val->validasi($_GET['id'],'sql')."'");
					  
	$r   = mysql_fetch_array($detail);
	
	$ukuran=explode(",",$r[ukuran]);
	$warna=explode(",",$r[warna]);
  
  include "anekawebconfig/diskon_stok1.php";
  
  $iden=mysql_fetch_array(mysql_query("SELECT * FROM identitas"));
?>
   <section id="content">
    <div class="container top">
      <div class="content_top">
<div class="wrapper_w">
          <div class="pull-left">
            <div class="breadcrumbs">
            <?php include "anekawebconfig/breadcrumb.php"; ?></div>
          </div>
        </div>
      </div>
      <div class="product-box">
        <div class="row">
          <div class="span6">
            <div class="product-img-box">
              <div class="row">
                <div class="span1">
                  <div class="more-views">
                    <ul>
                    <?php
					if($r[gambar_lain]!=''){
					$gambar_lain = explode(',', $r['gambar_lain']);
					foreach($gambar_lain as $gambar){
					if($gambar!=''){
					?>
					<li> 
                    <a class="cloud-zoom-gallery" href="<?php echo "$anekaweb/images/produk/$gambar";?>" title='<?php echo "$r[nama_produk]";?>' data-rel="useZoom: 'zoom1', smallImage: '<?php echo "$anekaweb/images/produk/$gambar";?>'"> 
                    
                    <img src="<?php echo "$anekaweb/images/produk/small_$gambar";?>" alt="<?php echo "$r[nama_produk]";?>" width="62" height="62"  /> </a> </li>
                                    
				  <?php
					}
						}
						  }
						?>
</ul>
                  </div>
                </div>
                <div class="span5">
                <div class="product-image"> 
                <a class="cloud-zoom" href="<?php echo "$anekaweb/images/produk/$r[gambar]";?>" id='zoom1' data-rel="position: 'right', adjustX: 10, adjustY: 0"> <img src="<?php echo "$anekaweb/images/produk/$r[gambar]";?>" alt="<?php echo "$r[nama_produk]";?>" width="405" /> </a>
                
                        </div>
                </div>
              </div>
            </div>
          </div>
          <div class="span6">
            <div class="product-shop">
              
              <div class="product_info_left">
                <div class="product-name">
                  <h1><?php echo "$r[nama_produk]";?></h1>
                  <?php
						//menampilkan rating produk
						$s=mysql_fetch_array(mysql_query("SELECT SUM(dibeli) AS total FROM produk"));
						$rating=round(($r[dibeli]/$s[total])*100);
						echo "<div class=\"basic\" data=\"".$rating."_".$id."\"></div>";
						?>
                </div>
                <p class="availability in-stock"> <span>Stok:<strong>Tersedia (<?php echo $r[stok];?>)</strong></span> </p>
                <div class="short-description"><?php echo $r[deskripsi];?></div>
                <div class="price-box"> 
                <?php echo $divharga;?>
                </div>
                
                <div class="add-to-cart">
                <form id="form-add_to_cart" name="getcart" action="<?php echo "aksi.php?module=keranjang&act=tambah&id=$r[id_produk]";?>" method="post">
                
                    <div class="qty">
                      <label for="qty">Item:</label>
                      <div class="select_wrapper width2">
                    <select name="qty" class="custom" tabindex="1">
					<?php
                    for($i=1;$i<=12;$i++){
                        echo "<option value='$i'>$i</option>";
                    }
                    ?>
                   </select>
                    </div>
                    </div>
                    <div class="qty">
                      <label for="qty">Ukuran:</label>
                      <div class="select_wrapper width2">
                    <select name="ukuran" class="custom" tabindex="1">
                        <?php
						foreach($ukuran as $u){
							echo "<option value='$u'>$u</option>";
						}
						?>
                    </select>
                    </div>
                    </div>
                     <div class="qty">
                      <label for="qty">Warna:</label>
                      <div class="select_wrapper width2">
                    <select name="warna" class="custom" tabindex="1">
                        <?php
						foreach($warna as $w){
							echo "<option value='$w'>$w</option>";
						}
						?>
                    </select>
                    </div>
                    </div>
                    
                    <button class="button btn-cart" title="Add to Cart" type="button" onClick="document.getElementById('form-add_to_cart').submit()"><?php echo $tombol;?></button>

                  </form>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="span12">
          <ul class="nav-tabs" id="myTab">
            <li class="active"><a href="#tab1">Deskripsi</a></li>
            <li><a href="#tab2">Komentar</a></li>
          </ul>
          <div class="tab-content">
            <div class="tab-pane active" id="tab1">
             <?php echo $r[deskripsi];?>
            </div>
            <div class="tab-pane" id="tab2">
          <div class="fb-comments" data-href="<?php echo " $iden[url]/produk-$r[id_produk]-$r[produk_seo].html";?>" data-width="970" data-num-posts="10" mobile="false"> 
            </div>
            
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <h2>Produk Lainnya</h2>
      <div class="carousel es-carousel-wrapper style0">
        <div class="es-carousel">
          <div class="row">
            <div class="product_outer">
               <?php
				 
			 $sql=mysql_query("SELECT * FROM produk ORDER BY id_produk DESC LIMIT 6");
			     while ($r=mysql_fetch_array($sql)){
			     include "anekawebconfig/diskon_stok.php";
                 $harga = number_format($r[harga],0,",",".");
				 ?>
                <div class="span3 product">
                <div class="product-image-wrapper">
                <div class="anekaweb-crop">
               <?php echo "<a href='produk-$r[id_produk]-$r[produk_seo].html'>
			               <img src='$anekaweb/images/produk/$r[gambar]' alt='$r[nama_produk]' width='229'>
                           <img src='$anekaweb/images/produk/$r[gambar]' class='roll_over_img' alt='$r[nama_produk]'></a>";?>
                   <?php echo "<div id='anekaweb_countdown_".$r['id_produk']."' class='countdown_box'>
                <script>updateWCTime('".date('F d, Y H:i:s',$r['diskon_expired'])."',$r[id_produk]);</script>
                </div>";?>         
                
                </div>
                </div>
                <div class="wrapper-hover">
                  <div class="product-name"> <?php echo "<a href='produk-$r[id_produk]-$r[produk_seo].html'>$r[nama_produk]</a>";?></div>
                  <div class="wrapper">
                  <?php echo"<div class='product-price' id='divharga".$r['id_produk']."'>$divharga</div>";?>
                   
                    
                  </div>
                </div>
              </div>
              
                 <?php } ?>
          </div>

          </div>
        </div>
        <div class="small_previews">
          <div class="small_preview prev hidden-phone hidden-tablet"><img src="img/small_preview.jpg" width="85" height="85" alt=""></div>
          <div class="small_preview next hidden-phone hidden-tablet"><img src="img/small_preview.jpg" width="85" height="85" alt=""></div>
        </div>
      </div>
    </div>
  </section>
  <div id="push"></div>
</div>