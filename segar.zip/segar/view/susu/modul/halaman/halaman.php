      <section id="content">
    <div class="container top"> 
    <div class="content_top">
      <div class="breadcrumbs">
      <?php include "anekawebconfig/breadcrumb.php"; ?></div>
       
      </div>
    <div class="row">
    <div class="span9" id="column_right">

  <!--========= DETAIL HALAMAN ========================-->  
  <?php			
  $detail=mysql_query("SELECT * FROM halamanstatis,users WHERE judul_seo='$_GET[judul]'");
  $d   = mysql_fetch_array($detail);
  $tgl_posting   = tgl_indo($d[tgl_posting]);
  $baca = $d[dibaca]+1;
  
  mysql_query("UPDATE halamanstatis SET dibaca='$baca' WHERE judul_seo='$_GET[judul]'");
	


  echo "
  <h2>$d[judul]</h2>
  <ul>
  <li class='post'>Ditulis: <a href='#'>$d[nama_lengkap]</a>, $d[hari], $tgl_posting - $d[jam] WIB</li>
  <li class='comment'>Komentar: <a href='#'>$baca pembaca</a></li>
  
  <div class='marginsharing'>
  <div class='addthis_toolbox addthis_default_style '>
  <a class='addthis_button_preferred_1'></a>
  <a class='addthis_button_preferred_2'></a>
  <a class='addthis_button_preferred_3'></a>
  <a class='addthis_button_preferred_4'></a>
  <a class='addthis_button_compact'></a>
  <a class='addthis_counter addthis_bubble_style'></a>
  </div> </div> 
  <script type='text/javascript' src='http://s7.addthis.com/js/250/addthis_widget.js#pubid=ra-504c13fd103cdd62'></script> 
  </ul>";
						

  if ($d[gambar]!=''){
						
  echo "
  <img src='img_statis/$d[gambar]'  alt='$d[judul]'  width='350' class='imagedetailblog' />
  <p>$d[isi_halaman]</p>
   </div>";}

    ?>  
</div>
          </div>
      
      
    <?php include "$f[folder]/modul/sidebar/sidebar-kontak.php";?>
        </div>
      </div>
    </div>
  </section>
  <div id="push"></div>
</div>