    <section id="content">
    <div class="container top">
    <div class="content_top">
    <div class="breadcrumbs"><?php include "anekawebconfig/breadcrumb.php"; ?></div>
    </div>
    <div class="row">
    <div class="span9" id="column_right">
    <h3>Profil Kami</h3>
    <?php 
    $profil=mysql_query("SELECT * FROM profil ORDER BY id_profil DESC");
    while($anekaweb=mysql_fetch_array($profil)){
    ?>
    <p><?php echo "$anekaweb[isi_profil]";?></p>
    <?php } ?>
    </div>
    <?php include "$f[folder]/modul/sidebar/sidebar.php";?>
    
    </div>
    </div>
    
    </div>
    
    </div>
    
    </div>
    
    </section>
    <div id="push"></div>
    </div>