    <section id="content">
    <div class="container top">
    <div class="content_top">
    <div class="breadcrumbs"><?php include "anekawebconfig/breadcrumb.php"; ?></div>
    </div>
    <div class="row">
    <div class="span9" id="column_right">
    <h3>Download Katalog</h3>
    <ul class="icons">
    <?php 
	
      $p      = new Paging5;
	  $batas  = 10;
  	  $posisi = $p->cariPosisi($batas);
	  
    $download=mysql_query("SELECT * FROM download ORDER BY id_download DESC LIMIT $posisi,$batas");
    while($d=mysql_fetch_array($download)){
    ?>
    <li><i class=" icon-down"></i><a href=<?php echo "downlot.php?file=$d[nama_file]";?> ><strong><?php echo "$d[judul]";?> </strong><b>(<?php echo "$d[hits]x";?>)</b></a></li>
    <?php } ?>
    </ul>
     <div class="line"></div>
    <?php
      $jmldata     = mysql_num_rows(mysql_query("SELECT * FROM download"));
      $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
      $linkHalaman = $p->navHalaman($_GET[haldownload], $jmlhalaman);
echo "<div class='paginator'>
      <ul id='pagination'>$linkHalaman
	  </ul>
      </div>";
      ?>
    </div>
    <?php include "$f[folder]/modul/sidebar/sidebar.php";?>
    </div>
    </div>
    
    </div>
    
    </div>
    
    </div>
    
    </section>
    <div id="push"></div>
    </div>