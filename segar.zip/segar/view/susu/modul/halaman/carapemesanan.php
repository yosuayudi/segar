    <section id="content">
    <div class="container top">
    <div class="content_top">
    <div class="breadcrumbs"><?php include "anekawebconfig/breadcrumb.php"; ?></div>
    </div>
    <div class="row">
    <div class="span9" id="column_right">
    <h3>Cara Pemesanan</h3>
    <?php 
    $pesan=mysql_query("SELECT * FROM carapemesanan ORDER BY id_pemesanan DESC");
    while($anekaweb=mysql_fetch_array($pesan)){
    ?>
    <p><?php echo "$anekaweb[pemesanan]";?></p>
    <?php } ?>
    </div>
    <?php include "$f[folder]/modul/sidebar/sidebar.php";?>
    </div>
    </div>
    </div>
    
    </div>
    
    </div>
    
    </section>
    <div id="push"></div>
    </div>