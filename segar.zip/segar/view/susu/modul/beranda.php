    <section class="slider">
    <div class="container">
    
  <div class="camera_wrap camera_emboss " id="camera_wrap_1">
					
  <?php
  $header=mysql_query("SELECT * FROM header INNER JOIN kategoriproduk ON header.id_kategori=kategoriproduk.id_kategori
  ORDER BY id_header DESC LIMIT 5");
  while($b=mysql_fetch_array($header)){

  echo "
  <div data-src='images/header/$b[gambar]'>
  <div class='camera_caption moveFromLeft'>
  <h2>$b[judul]</h2>
  <p>$b[keterangan]</p>
  <div class='button'>
  <a href='kategoriproduk-$b[id_kategori]-$b[kategori_seo].html' >Lihat Koleksi</a>
  </div>
  </div>
  </div>";}
  ?>		
  </div>


    </div>
    </section>
  
    <!--CONTENT-->
    <section id="content">
    <div class="container">
    <div class="row">
          
    <div class="span9" id="column_right">

    <?php $iden=mysql_fetch_array(mysql_query("SELECT * FROM identitas")); ?>
    <h2>Selamat Datang di <?php echo "$iden[nama_website]";?></h2>
    <?php
    $sql=mysql_query("SELECT * FROM selamatdatang ORDER BY id_selamatdatang");
    while ($r=mysql_fetch_array($sql)){
    ?>
    <p><?php echo "$r[selamatdatang]";?></p>
    <?php } ?>
      <div class="line1"></div>
      
      
      <div class="listing_header_row1">

      <?php
      // Tentukan berapa data yang akan ditampilkan per halaman (paging)
      $p      = new Pagination("media.php?module=store");
      $batas  = isset($_GET['perpage']) ? abs((int)$_GET['perpage']) : 21;
      $posisi = $p->cariPosisi($batas);
      $order_by = isset($_GET['order_by']) ? strip_tags($_GET['order_by']) : 'terbaru';
      $order_array = array('terbaru' => 'id_produk', 'terlaris' => 'dibeli', 'abjad' => 'nama_produk', 'diskon' => 'diskon');
    
      // Tampilkan semua produk
      $sql=mysql_query("SELECT * FROM produk ORDER BY ".$order_array[$order_by]." DESC LIMIT $posisi,$batas");
      $order_combo = array(
	  'terbaru' => 'Terbaru',
      'terlaris' => 'Terlaris',
      'abjad' => 'Abjad',
      'diskon' => 'Diskon');
      $perpage_combo = array(21,50,80,100);
        
echo '<div class="pull-left">
	  <label>Sort by:</label>
	  <div class="select_wrapper width1">
	   <form action="media.php" method="get">
	  <input type="hidden" name="module" value="store">
	  <select name="order_by" class="custom" tabindex="1" onchange="this.form.submit()">';
	  foreach($order_combo as $key => $val){
	  $selected = $key==$order_by ? 'selected' : '';
echo '<option value="'.$key.'" '.$selected.'>'.$val.'</option>';
	  }
echo '</select>
      </div>
      </div>
      <div class="pull-right alignright">
      <label><span class="hidden-phone">Show:</span></label>
      <div class="select_wrapper width2">
      <select name="perpage" class="custom" tabindex="1" onchange="this.form.submit()">';
      foreach($perpage_combo as $perpage){
      $selected = $perpage==$batas ? 'selected' : '';
echo '<option value="'.$perpage.'" '.$selected.'>'.$perpage.'</option>';
        }
echo '</select>
      </form>';
echo '</div>
      per&nbsp;page</div>
      </div>
      <div class="line1"></div>
      <div class="listing_header_row2">
      <div class="pull-right">';
    
	  $jmldata     = mysql_num_rows(mysql_query("SELECT * FROM produk"));
	  $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
	  $linkHalaman = $p->navHalaman($_GET[page], $jmlhalaman);
	  
echo "<div class='num'>$linkHalaman
	  </div>
      </div>
      </div>";
      ?>
	 
      <div class="row big_with_description">
	  <?php
      while ($r=mysql_fetch_array($sql)){
      include "anekawebconfig/diskon_stok.php";
      $harga = number_format($r[harga],0,",",".");
      ?>
                <div class="span3 product">
                <div class="product-image-wrapper">
                <div class="anekaweb-crop">
               <?php echo "<a href='produk-$r[id_produk]-$r[produk_seo].html'>
			               <img src='$anekaweb/images/produk/$r[gambar]' alt='$r[nama_produk]' width='229'>
                           <img src='$anekaweb/images/produk/$r[gambar]' class='roll_over_img' alt='$r[nama_produk]'></a>";?>
                   <?php echo "<div id='anekaweb_countdown_".$r['id_produk']."' class='countdown_box'>
                <script>updateWCTime('".date('F d, Y H:i:s',$r['diskon_expired'])."',$r[id_produk]);</script>
                </div>";?>         
                
                </div>
                </div>
                <div class="wrapper-hover">
                  <div class="product-name"> <?php echo "<a href='produk-$r[id_produk]-$r[produk_seo].html'>$r[nama_produk]</a>";?></div>
                  <div class="wrapper">
                  <?php echo"<div class='product-price' id='divharga".$r['id_produk']."'>$divharga</div>";?>
                   
                    
                  </div>
                </div>
              </div>
              
                 <?php } ?>
          </div>
         <div class="line1"></div>
      <div class="listing_header_row1">
       <div class="pull-left">
	  <label>Sort by:</label>
	  <div class="select_wrapper width1">
      <?php 
echo '<form action="media.php" method="get">
	  <input type="hidden" name="module" value="store">
	  <input type="hidden" name="id" value="'.abs((int)$_GET['id']).'">
	  <select name="order_by" class="custom" tabindex="1" onchange="this.form.submit()">';
	  foreach($order_combo as $key => $val){
	  $selected = $key==$order_by ? 'selected' : '';
echo '<option value="'.$key.'" '.$selected.'>'.$val.'</option>';
	  }
echo '</select>
      </div>
      </div>
      <div class="pull-right alignright">
      <label><span class="hidden-phone">Show:</span></label>
      <div class="select_wrapper width2">
      <select name="perpage" class="custom" tabindex="1" onchange="this.form.submit()">';
      foreach($perpage_combo as $perpage){
      $selected = $perpage==$batas ? 'selected' : '';
echo '<option value="'.$perpage.'" '.$selected.'>'.$perpage.'</option>';
        }
echo '</select>
      </form>';
echo '</div>
      per&nbsp;page</div>
      </div>
      <div class="line1"></div>
      <div class="listing_header_row2">
      <div class="pull-right">';
    
	  $jmldata     = mysql_num_rows(mysql_query("SELECT * FROM produk"));
	  $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
	  $linkHalaman = $p->navHalaman($_GET[page], $jmlhalaman);
	  
echo "<div class='num'> $linkHalaman</div>
      </div>
      </div>
      </div>";
      ?>
      <?php include "$f[folder]/modul/sidebar/sidebar.php";?>
      </div>
      </div> 
      </div>
      </section>
      

    <div id="bottom_block">
        <div class="container">
      <div class="row">
        <div class="span6">
          <div class="row">
            <div class="span3">
              <h4>Profil <?php echo "$iden[nama_website]";?></h4>
              <div class="cleancode">
               <?php
				  $tampil = mysql_query("SELECT * FROM profil ORDER BY id_profil DESC");
				  while ($b=mysql_fetch_array($tampil)){
				  
				  $isi_profil = strip_tags($b['isi_profil']); // membuat paragraf pada isi profil dan mengabaikan tag html
				  $isi_profil = substr($isi_profil,0,480); // ambil sebanyak 400 karakter
				  $isi_profil = substr($isi_profil,0,strrpos($isi_profil," ")); // potong per spasi kalimat
				  ?>
                <p><?php echo "$isi_profil...";?></p>
                <?php } ?>
              </div>
            </div>
            <div class="span3">
              <h4>FACEBOOK</h4>
              <div class="fb_outer">
                <?php
				$sql2 = mysql_query("select facebook from identitas LIMIT 1");
				$AWfb   = mysql_fetch_array($sql2);
		  echo "<div class='fb-container'>
				<div class='fb-like-box'
				data-width='275' data-height='250'
				data-href='$AWfb[facebook]'
				data-border-color='white' data-show-faces='true'
				data-colorscheme='light'
				data-stream='false' data-header='false'>
				</div>
				</div>
				<div id='fb-root'></div>";
				?>
              </div>
            </div>
          </div>
        </div>
        
        <div class="span6">
          <div class="row">
            <div class="span3">
              <h4>TWITTER</h4>
              
              <div class="twit">
                <ul class="icons">
                 <?php
                          echo "  <a class='twitter-timeline' data-dnt='true' href='https://twitter.com/$iden[user_twitter]' data-widget-id='$iden[twitter]'></a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','twitter-wjs');</script>";
?>
                </ul>
              </div>
              
              
              
              
               </div>
               
               
               
            <div class="span3">
              <h4>ALAMAT</h4>
              <div class="cleancode">
              <p><?php echo "$iden[alamat]";?></p>
                <ul class="icons">
                  <li><i class="icon-mobile-alt"></i><strong><?php echo "$iden[no_telp]";?></strong><br>
                    </li>
                  <li><i class="icon-mail-1"></i><strong><?php echo "$iden[email]";?> </strong><br>
                    </li>
                  <li><i class="icon-clock"></i><strong><?php echo "$iden[jam_kerja]";?></strong><br>
                    </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <div id="push"></div>
</div>