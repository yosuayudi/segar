<section id="content">
  <div class="container top">
   <div class="content_top">
      <div class="breadcrumbs">
      <?php include "anekawebconfig/breadcrumb.php"; ?></div>
       
      </div>
    <div class="row">
      <div class="span9" id="column_right">
  <h3>Peta Lokasi</h3>
   
  <?php 
   $iden=mysql_fetch_array(mysql_query("SELECT * FROM identitas"));
      $peta= mysql_query("SELECT * FROM identitas");
	  $p = mysql_fetch_array($peta);
	  $pecahd = explode(",", $p[peta]);
	  $width = $pecahd[0];
	  $height = $pecahd[1];
	  $longtitude = $pecahd[2];
	  $latitude = $pecahd[3];	
  echo "
  <script src='https://maps.googleapis.com/maps/api/js?v=3.exp'></script><div style='overflow:hidden;$height$width'><div id='gmap_canvas' style='$height$width'></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style></div> <a href='https://mapswebsite.net/'>google map embed</a> <script type='text/javascript' src='https://embedmaps.com/google-maps-authorization/script.js?id=9dacf49d856d48ac05328452029624720cb6df64'></script><script type='text/javascript'>function init_map(){var myOptions = {zoom:18,center:new google.maps.LatLng($longtitude,$latitude),mapTypeId: google.maps.MapTypeId.TERRAIN};map = new google.maps.Map(document.getElementById('gmap_canvas'), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng($longtitude,$latitude)});infowindow = new google.maps.InfoWindow({content:'<strong>$iden[nama_website]</strong><br>$iden[alamat]<br>'});google.maps.event.addListener(marker, 'click', function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>";
  ?>  		

  <br/> <br/><h3>Form Kontak Kami</h3>
                     
  <form action="kontak-aksi.html" method="post" id="form-contact">
        <div class="row">
          <div class="span4">
            <p>Nama:</p>
            <input required type="text" name="nama">
          </div>
          </div>
          <div class="row">
          <div class="span4">
            <p>Email:</p>
            <input required type="text" name="email">
          </div>
        </div>
        <div class="row">
          <div class="span4">
            <p>Subjek:</p>
            <input required type="text" name="subjek">
          </div>
        </div>
        <div class="row">
          <div class="span7">
            <p>Pesan:</p>
            <textarea required name="pesan" cols="1" rows="1" ></textarea>
          </div>
        </div>
        <div class="row">
          <div class="span3">
           <p>Kode: </p>
            <div class="pull-left margin-2"><img src="captcha/captcha.php?rand=<?php echo rand(); ?>" id="captchaimg" ></div>
            <div class="pull-left padding-2"><input required type="text" name="kode" class="input-small">
            <p>huruf tidak ke baca? klik <a href='javascript: refreshCaptcha();'>disini</a> refresh</p></div><br/>
            </div>
          </div>
              <div class="pull-left margin-2">
                <button class="button-2x" onClick="document.getElementById('form-contact').submit()">KIRIM</button>
            </div>
        </form>   
			</div>		
       
    <?php include "$f[folder]/modul/sidebar/sidebar.php";?>
        </div>
      </div>
    </div>
  </section>
  <div id="push"></div>
</div>