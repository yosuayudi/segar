  <section id="content">
  <div class="container top">
   <div class="content_top">
      <div class="breadcrumbs">
      <?php include "anekawebconfig/breadcrumb.php"; ?></div>
       
      </div>
    <div class="row">
      <div class="span9" id="column_right">
  <h3>Kontak Kami</h3>
  <div class="content-wrap">
 
  <?php         
  
  $nama=trim($_POST[nama]);
  $email=trim($_POST[email]);
  $subjek=trim($_POST[subjek]);
  $pesan=trim($_POST[pesan]);
  
  $anekaweb=mysql_fetch_array(mysql_query("SELECT * FROM identitas"));

  if (empty($nama)){
  echo "<p>Anda belum mengisikan NAMA</p>
  <a href=javascript:history.go(-1)><input type='submit' 
  class='button' value='Ulangi Lagi' name='submit'/></a>";}
		  
  elseif (empty($email)){
  echo "<p>Anda belum mengisikan EMAIL</p>
  <a href=javascript:history.go(-1)><input type='submit' 
  class='button' value='Ulangi Lagi' name='submit'/></a>";}
		  

  elseif (empty($subjek)){
  echo "<p>Anda belum mengisikan SUBJEK</p>
  <a href=javascript:history.go(-1)><input type='submit' 
  class='button' value='Ulangi Lagi' name='submit'/></a>";}
  
  elseif (empty($pesan)){
  echo "<span class='new-comment-heading'>Anda belum mengisikan PESAN</span>
  <a href=javascript:history.go(-1)><input type='submit' 
  class='contact-form-button' value='Ulangi Lagi' name='submit'/></a>";}
  
  else{
  if(!empty($_POST['kode'])){
  if($_POST['kode']==$_SESSION['captcha_session']){

  mysql_query("INSERT INTO hubungi(nama,
                                   email,
                                   subjek,
                                   pesan,
                                   tanggal) 
                        VALUES('$_POST[nama]',
                               '$_POST[email]',
                               '$_POST[subjek]',
                               '$_POST[pesan]',
                               '$tgl_sekarang')");
 
 
  echo "
  <h4>Terima Kasih</h4>
  <p>Anda telah menghubungi $anekaweb[nama_website], kami segera merespon pesan anda.</p>
   <img src='$f[folder]/img/load.gif' width='200' height='15'/>
   <meta http-equiv='refresh' content='2; url=index.php'>";
   
   
   $kepada = "$anekaweb[email]"; 
   $judul = "Ada Pesan di $anekaweb[nama_website]";
   $pesan = "Baru saja ada yang kirim pesan di $anekaweb[nama_website]\n"; 
   $pesan .= "Cek Administrator: $anekaweb[url]/editweb"; 
   mail($kepada,$judul,$pesan,"From: $anekaweb[email]\n Content-type:text/html\r\n"); }
  
  else{
  echo "</p>Kode yang Anda masukkan tidak cocok !</p>
  <a href=javascript:history.go(-1) class='contactForm'>
  <input type='submit' class='button' value='Ulangi Lagi' name='submit'/></a><br/>";}}
  
  else{
  echo "<p>Anda belum memasukkan kode</p>
  <a href=javascript:history.go(-1)><input type='submit' 
  class='button' value='Ulangi Lagi' name='submit'/></a>";}}
    
		  
  ?>
        </div>  

        </div>  
    <?php include "$f[folder]/modul/sidebar/sidebar-kontak.php";?>
        </div>
      </div>
    </div>
  </section>
  <div id="push"></div>
</div>