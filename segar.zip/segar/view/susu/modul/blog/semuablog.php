      <!--CONTENT-->
      <section id="content">
      <div class="container top">
      <div class="content_top">
      <div class="breadcrumbs">
      <?php include "anekawebconfig/breadcrumb.php"; ?></div>
       
      </div>
      <div class="row">
      <div class="span9">
	  <?php
      $p      = new Paging4;
      $batas  = 6;
      $posisi = $p->cariPosisi($batas);
  
      $AWblog=mysql_query("SELECT * FROM blog,users WHERE users.username=blog.username
	  ORDER BY id_blog DESC LIMIT $posisi,$batas");
      while($r=mysql_fetch_array($AWblog)){
      $tgl = tgl_indo($r[tanggal]);
      $baca = $r[dibaca]+1;
  
      $isi_blog =(strip_tags($r[isi_blog])); 
      $isi = substr($isi_blog,0,280); 
      $isi = substr($isi_blog,0,strrpos($isi," ")); 
	   
echo "<div class='post-preview'>
	  <h3><a href='blog-$r[id_blog]-$r[judul_seo].html'>$r[judul]</a></h3>
	  <div class='image'>";
	  if ($r['gambar']!=''){
echo "<img src='$anekaweb/images/blog/$r[gambar]' alt='$r[judul]' class='img-responsive img-rounded' height='301' width='733'></div>
	  <div class='post-meta'> 
	  <span class='meta-date'>
	  <i class='icon-clock-alt'></i>$tgl</span> 
	  <span class='meta-author'><i class='icon-user-2'></i><a href='#'>$r[nama_lengkap]</a></span>              
	  <span class='meta-views'><i class='icon-cog-1'></i><a href='#'>$baca pembaca</a></span> </div>
	  <p>$isi.. </p>
	  <p><a class='button' href='blog-$r[id_blog]-$r[judul_seo].html'>Selengkapnya</a></p>
	  </div>
	  <div class='line'></div>";
	  }		
	  }		
						
	  $jmldata     = mysql_num_rows(mysql_query("SELECT * FROM blog"));
	  $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
	  $linkHalaman = $p->navHalaman($_GET[halblog], $jmlhalaman);

echo "<div class='paginator'>
	  <ul id='pagination'>$linkHalaman</div></ul>";
	  ?>
        
        </div>
        
    <?php include "$f[folder]/modul/sidebar/sidebar.php";?>
        
        
        </div>
      </div>
    </div>
  </section>
  <div id="push"></div>
</div>