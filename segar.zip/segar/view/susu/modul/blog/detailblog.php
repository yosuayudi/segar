<!--CONTENT-->
  <section id="content">
    <div class="container top">
         <div class="content_top">
<div class="wrapper_w">
          <div class="pull-left">
            <div class="breadcrumbs">
            <?php include "anekawebconfig/breadcrumb.php"; ?></div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="span9">
          <div class="post-preview">
		  <?php
		  			
		  $detail=mysql_query("SELECT * FROM blog,users
		                                WHERE users.username=blog.username 
										AND id_blog='".$val->validasi($_GET['id'],'sql')."'");
		  $d   = mysql_fetch_array($detail);
		  
		  $tgl = tgl_indo($d[tanggal]);
		  $baca = $d[dibaca]+1;
		  
		  
		  mysql_query("UPDATE blog SET dibaca='$baca' WHERE id_blog='".$val->validasi($_GET['id'],'sql')."'");
		  
		  $iden=mysql_fetch_array(mysql_query("SELECT * FROM identitas"));
		  
		  ?>
            <h1><?php echo "$d[judul]";?></h1>
            <div class="post-meta"> 
            <span class="meta-date"><i class="icon-clock-alt"></i><?php echo "$tgl";?></span> 
            <span class="meta-author"><i class="icon-user-2"></i><a href="#"><?php echo "$d[nama_lengkap]";?></a></span> 
            <span class="meta-views"><i class="icon-cog-1"></i><a href="#"><?php echo "$baca pembaca";?></a></span> 
            </div>
            <div class="image">
			<?php echo " <img src='$anekaweb/images/blog/$d[gambar]' alt='$r[judul]' width='800'>";?>
            </div>
            
            <p><?php echo "$d[isi_blog]";?></p>
            
            <?php
            //NEXT-PREV BLOG///////////////////////////////////////////////////////////////////////
	  
			  $qp = mysql_query("select id_blog, judul, judul_seo from blog 
								 where id_blog < '".$val->validasi($_GET['id'],'sql')."' 
								 order by id_blog desc limit 1");
			  $jp = mysql_num_rows($qp);
			  $tp = mysql_fetch_array($qp);
			  
			  $qn = mysql_query("select id_blog, judul, judul_seo from blog 
								 where id_blog > '".$val->validasi($_GET['id'],'sql')."' 
								 order by id_blog asc limit 1");
			  $jn = mysql_num_rows($qn);
			  $tn = mysql_fetch_array($qn);
			 
              
		echo "<div class='post-navigation'>";
			  if($jp <> 0) { 
		echo "<div class='pull-left'><i class='icon-left-open'></i>&nbsp;<a href='blog-$tp[id_blog]-$tp[judul_seo].html'>$tp[judul]</a></div>";
			   }
			  if($jn <> 0) {
		echo "<div class='pull-right'><a href='blog-$tn[id_blog]-$tn[judul_seo].html'>$tn[judul]</a>&nbsp;<i class='icon-right-open'></i></div>";
			  } 
		echo "</div>";

			     ?>
                
                
            <div class="line"></div>
            
              <br>
              <br>
                <?php 
                 $sq = mysql_query("SELECT * from blog where id_blog='".$val->validasi($_GET['id'],'sql')."'");
  $n = mysql_fetch_array($sq);
  $iden=mysql_fetch_array(mysql_query("SELECT * FROM identitas"));
  
  echo "<h3>Komentar Blog &mdash; <span style='color:#999; font-size: 16px;'>$d[judul]</span></h3>
  <div class='fb-comments' data-href='$iden[url]/blog-$n[id_blog]-$n[judul_seo].html' data-num-posts='20' data-width='100%'>";

			     ?>
            </div>
          </div>
        </div>
        
        
    <?php include "$f[folder]/modul/sidebar/sidebar.php";?>
        
        
        </div>
      </div>
    </div>
  </section>
  <div id="push"></div>
</div>