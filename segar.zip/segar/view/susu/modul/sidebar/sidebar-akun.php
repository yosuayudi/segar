    <div class="span3" id="column_left">
    <div class="row">
    <div class="span3">
    <div class="block_listing">
    <div class="block block-layered-nav">
      <div class="block">
      <div class="block-title"><strong><span>Menu Profil</span></strong></div>
      <div class="block-content">
      <dd class="odd">
       <ol>
      <?php
      $sql=mysql_query("SELECT * FROM menumember WHERE aktif='Y'");
	  while($r=mysql_fetch_array($sql)){
echo "<li><a href='$r[link]'><strong>$r[nama_menu] </strong></a></li>";
	   }
      ?>
       </ol>
       </dd>
      </div>
      </div>
     
      </div>
      </div>
      
      
       <div class="block">
    <div class="block-title">
    <strong><span>Produk Terlaris</span></strong>
    </div>
    <div class="banners_outer">
    <div class="flexslider banners">
    <ul class="slides">
    <?php
    
    $sql=mysql_query("SELECT * FROM produk WHERE dibeli ORDER BY id_produk DESC LIMIT 6");
    while ($r=mysql_fetch_array($sql)){
    include "anekawebconfig/diskon_stok.php";
    $harga = number_format($r[harga],0,",",".");
    ?>
    <li>
    <div class="product-terlaris">
    <div class="product-image-wrapper">
    <div class="anekaweb-crop">
    <?php echo "<a href='produk-$r[id_produk]-$r[produk_seo].html'>
			   <img src='$anekaweb/images/produk/$r[gambar]' alt='$r[nama_produk]' width='229'>
			   <img src='$anekaweb/images/produk/$r[gambar]' class='roll_over_img' alt='$r[nama_produk]'></a>";?>
	   <?php echo "<div id='anekaweb_countdown1_".$r['id_produk']."' class='countdown_box'>
	<script>updateAnekaWebTime('".date('F d, Y H:i:s',$r['diskon_expired'])."',$r[id_produk]);</script>
	</div>";?>      
    
    </div>
    </div>
    <div class="wrapper-hover">
    <div class="product-name"> <?php echo "<a href='produk-$r[id_produk]-$r[produk_seo].html'>$r[nama_produk]</a>";?></div>
    <div class="wrapper">
    <?php echo"<div class='product-price' id='divharga".$r['id_produk']."'>$divharga</div>";?>
    
    </div>
    </div>
    </div>
    
    </li>
    <?php } ?>
    </ul>
    </div>
    </div>
    </div>
      
     
    </div>
    </div>