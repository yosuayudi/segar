    <div class="span3" id="column_left">
    <div class="row">
    <div class="span3">
    <div class="block_listing">
    <div class="block block-layered-nav">
  <!--  <div class="block-title"><strong><span>Alamat</span></strong></div>
    <div class="block-content">
	<?php echo "$iden[alamat]";?>
    </div>
    </div>
    </div>
              
              
   <div class="block">
    <div class="block-title"><strong><span>Online Support</span></strong></div>
    <div class="block-content">
     <?php
    $ym=mysql_query("select * from mod_ym order by id desc");
    $no=1;
    while($t=mysql_fetch_array($ym)){
    echo "<div class='ym-txt'>$t[nama] </div>
    <div class='img-ym'>
    <a href='ymsgr:sendIM?$t[ym]'>
    <img src='http://opi.yahoo.com/online?u=$t[ym]&amp;m=g&amp;t=1'></a></div><br/>";
    $no++;
    }
    ?>
    </div>
    </div> -->
    
     
    </div>
    </div>