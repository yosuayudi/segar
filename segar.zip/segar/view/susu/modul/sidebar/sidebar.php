    <div class="span3" id="column_left">
    <div class="row">
    <div class="span3">
    <div class="block_listing">
    <div class="block block-layered-nav">
    <!--div class="block-title"><strong><span>Alamat</span></strong></div>
    <div class="block-content">
   
	<?php echo "$iden[alamat]";?>
    </div>
    </div>
    </div>
              
              
    <div class="block">
    <div class="block-title"><strong><span>Online Support</span></strong></div>
    <div class="block-content" > 
    <?php
    $ym=mysql_query("select * from mod_ym order by id desc");
    $no=1;
    while($t=mysql_fetch_array($ym)){
    echo "<div class='ym-txt'>$t[nama] </div>
    <div class='img-ym'>
    <a href='ymsgr:sendIM?$t[ym]'>
    <img src='http://opi.yahoo.com/online?u=$t[ym]&amp;m=g&amp;t=1'></a></div><br/>";
    $no++;
    }
    ?>
    </div>
    </div>-->
    
    
    
    <div class="block">
    <div class="block-title">
    <strong><span>Produk Terlaris</span></strong>
    </div>
    <div class="banners_outer">
    <div class="flexslider banners">
    <ul class="slides">
    <?php
    
    $sql=mysql_query("SELECT * FROM produk WHERE dibeli ORDER BY id_produk DESC LIMIT 6");
    while ($r=mysql_fetch_array($sql)){
    include "anekawebconfig/diskon_stok.php";
    $harga = number_format($r[harga],0,",",".");
    ?>
    <li>
    <div class="product-terlaris">
    <div class="product-image-wrapper">
    <div class="anekaweb-crop">
    <?php echo "<a href='produk-$r[id_produk]-$r[produk_seo].html'>
			   <img src='$anekaweb/images/produk/$r[gambar]' alt='$r[nama_produk]' width='229'>
			   <img src='$anekaweb/images/produk/$r[gambar]' class='roll_over_img' alt='$r[nama_produk]'></a>";?>
	   <?php echo "<div id='anekaweb_countdown1_".$r['id_produk']."' class='countdown_box'>
	<script>updateAnekaWebTime('".date('F d, Y H:i:s',$r['diskon_expired'])."',$r[id_produk]);</script>
	</div>";?>      
    
    </div>
    </div>
    <div class="wrapper-hover">
    <div class="product-name"> <?php echo "<a href='produk-$r[id_produk]-$r[produk_seo].html'>$r[nama_produk]</a>";?></div>
    <div class="wrapper">
    <?php echo"<div class='product-price' id='divharga".$r['id_produk']."'>$divharga</div>";?>
    
    </div>
    </div>
    </div>
    
    </li>
    <?php } ?>
    </ul>
    </div>
    </div>
    </div>
      
    <div class="block">
    <div class="block-title"><strong><span>Status Order</span></strong></div>
    <div class="block-content">
    <p>Masukan ID ORDER anda :</p>
    <form action="cek-order.html" method="post" class="form-mail1" >
    <input required type="text" class="search-query" value="masukan id order..." onBlur="if (this.value == '') {this.value = 'masukan id order...';}" onFocus="if(this.value == 'masukan id order...') {this.value = '';}">
    <button type="submit" class="btn"><i class="icon-email"></i></button>
    </form>
    </div>
    </div>
           
      
      <!--<div class="block">
      <div class="block-title"><strong><span>Rekening Bank</span></strong></div>
      <div class="block-content">
     <?php
      $bank=mysql_query("SELECT * FROM mod_bank ORDER BY id_bank ASC");
      while($b=mysql_fetch_array($bank)){
echo "<div class='img-bank'><img width=90 src='images/banner/$b[gambar]'></div>
	  <div class='rek-bank'><p class='block-subtitle'>$b[no_rekening]</p> </div>
	  <div class='bank'><p class='block-subtitle'>$b[pemilik]</p> </div>";
	   }
      ?>
      </div>
      </div>
        
            
              
    <div class="block">
      <?php 
    $banner=mysql_query("SELECT * FROM promo ORDER BY id_promo DESC LIMIT 3");
    while($d=mysql_fetch_array($banner)){
echo "<a href='$d[url]'><img src='images/banner/$d[gambar]' width='256' height='153' alt='$d[judul]'></a>";	  
    }
    ?>
    </div> -->
     
      <div class="block">
      <div class="block-title"><strong><span>Download katalog</span></strong></div>
      <div class="block-content">
      <?php
      $sql=mysql_query("SELECT * FROM download ORDER BY id_download DESC LIMIT 3");
	  while($d=mysql_fetch_array($sql)){
echo "<i class='icon-down'></i>&nbsp;&nbsp;<a href='downlot.php?file=$d[nama_file]' ><strong>$d[judul] </strong><b>($d[hits]x)</b></a>";
	   }
      ?>
      </div>
      </div>
     
    <div class="block">
    <div class="block-title"><strong><span>Berita Terbaru</span></strong></div>
    <div class="block-content">
    <?php 
	// Tampilkan berita	  
	$sql=mysql_query("SELECT * FROM blog ORDER BY id_blog DESC LIMIT 4");	 
	while($d=mysql_fetch_array($sql)){
	
	$isi_blog = strip_tags($d['isi_blog']); // membuat paragraf pada isi profil dan mengabaikan tag html
	$isi_blog = substr($isi_blog,0,70); // ambil sebanyak 400 karakter
	$isi_blog = substr($isi_blog,0,strrpos($isi_blog," ")); // potong per spasi kalimat
		   	     
echo"<div class='twit'>
    <p class='block-subtitle'><a href='blog-$d[id_blog]-$d[judul_seo].html'>$d[judul]</a></p>
    <div class='AWimg'>
	<a href='blog-$d[id_blog]-$d[judul_seo].html'>
	<img src='images/blog/small_$d[gambar]' alt='$d[judul]'></a>
	</div>
    <div class='mess'>$isi_blog</div>
    </div>";
	}
    ?>
    </div>
    </div>
    
  <div class="block">
    <div class="block-title"><strong><span>Testimonial</span></strong></div>
    <div class="block-content">
    <?php 
	// Tampilkan Testimonial	  
	$sql=mysql_query("SELECT * FROM testimonial ORDER BY id_testimonial DESC LIMIT 3");	 
	while($d=mysql_fetch_array($sql)){
	$tgl = tgl_indo($d['tanggal']);
    
     $grav_url = 'http://www.gravatar.com/avatar/' . md5( strtolower( trim( $d[email] ) ) ) . '?d=' . urlencode(      $default ) . '&s=' .  
     $size;;
    
     if ($d[email]!=''){
		   	     
echo"<div class='twit'>
    <p class='block-subtitle'>$d[nama]</p>
    <p>$d[kota], $tgl</p>
    <div class='AWimg'>
	<img src='$grav_url' alt='$d[nama]'></div>";
     }
     else{
echo"<div class='AWimg'>
	<img src='$f[folder]/img/bg_user.png' alt='$d[nama]'></div>";
    }
echo"
    <div class='mess'>$d[pesan]</div>
    </div>";
	}
    ?>
    </div>
    </div>
     
     
    </div>
    </div>