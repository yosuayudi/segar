    <section id="content">
    <div class="container top"> 
    <div class="content_top">
      <div class="breadcrumbs">
      <?php include "anekawebconfig/breadcrumb.php"; ?></div>
       
      </div>
    <div class="row">
    <div class="span9" id="column_right">
    <h1>Testimonial</h1>
        <?php 
	
	 $p      = new Paging6;
     $batas  = 10;
     $posisi = $p->cariPosisi($batas);
	
     $testi=mysql_query("SELECT * FROM testimonial ORDER BY id_testimonial DESC LIMIT $posisi,$batas");
     while($s=mysql_fetch_array($testi)){
     $tgl = tgl_indo($s['tanggal']);
    
     $grav_url = 'http://www.gravatar.com/avatar/' . md5( strtolower( trim( $s[email] ) ) ) . '?d=' . urlencode(      $default ) . '&s=' .  
     $size;;
    
     if ($s[email]!=''){
echo"<div class='testimonials'>
     <div class='images'><img src='$grav_url' width='60' height='60'></div>";
     }
     else{
echo"<div class='testimonials'>
	 <div class='images'><img src='$f[folder]/img/bg_user.png' width='60' height='60'></div>";
	  }
echo"<p>$s[pesan]</p>
	 </div>
	 <p class='testimonials_author'>
	 <a href='mailto:$s[email]' target='_blank class='view'>
	 <em>$s[nama]</em>,</a> <span class='color'>$s[kota], $tgl, $s[jam] </span></p>";
      } 					
	  $jmldata     = mysql_num_rows(mysql_query("SELECT * FROM testimonial"));
	  $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
	  $linkHalaman = $p->navHalaman($_GET[haltestimonial], $jmlhalaman);

echo "<br/><div class='line'></div>
      <div class='paginator'>
	  <ul id='pagination'>$linkHalaman</div></ul>";
	  ?>
       <div class="line"></div><br/>
        
        <form action="testimonial-aksi.html" method="post" id="form-contact">
        <div class="row">
          <div class="span4">
            <p>Nama:</p>
            <input required type="text" name="nama">
          </div>
          </div>
          <div class="row">
          <div class="span4">
            <p>Email:</p>
            <input required type="text" name="email">
          </div>
        </div>
        <div class="row">
          <div class="span4">
            <p>Kota:</p>
            <input required type="text" name="kota">
          </div>
        </div>
        <div class="row">
          <div class="span7">
            <p>Pesan:</p>
            <textarea required name="pesan" cols="1" rows="1" ></textarea>
          </div>
        </div>
          <div class="row">
          <div class="span3">
           <p>Kode: </p>
            <div class="pull-left margin-2"><img src="captcha/captcha.php?rand=<?php echo rand(); ?>" id="captchaimg" ></div>
            <div class="pull-left padding-2"><input required type="text" name="kode" class="input-small">
            <p>huruf tidak ke baca? klik <a href='javascript: refreshCaptcha();'>disini</a> refresh</p></div><br/>
            </div>
          </div>
              <div class="pull-left margin-2">
                <button class="button-2x" onClick="document.getElementById('form-contact').submit()">KIRIM</button>
            </div>
        </form>
      </div>
      
      
    <?php include "$f[folder]/modul/sidebar/sidebar.php";?>
        </div>
      </div>
    </div>
  </section>
  <div id="push"></div>
</div>