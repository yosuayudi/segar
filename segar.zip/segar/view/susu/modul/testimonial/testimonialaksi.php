     <section id="content">
    <div class="container top"> 
    <div class="content_top">
      <div class="breadcrumbs">
      <?php include "anekawebconfig/breadcrumb.php"; ?></div>
       
      </div>
    <div class="row">
    <div class="span9" id="column_right">
    <h1>Testimonial</h1>
  <div class="content-wrap">

  <?php         
  
       
  $nama=trim($_POST[nama]);
  $email=trim($_POST[email]);
  $kota=trim($_POST[kota]);
  $pesan=trim($_POST[pesan]);
  

  $anekaweb=mysql_fetch_array(mysql_query("SELECT * FROM identitas"));

	   
  if (empty($nama)){
  echo "<p>Anda belum mengisikan NAMA</p>
  <a href=javascript:history.go(-1)><input type='submit' 
  class='button' value='Ulangi Lagi' name='submit'/></a>";}
		  
  elseif (empty($email)){
  echo "<p>Anda belum mengisikan EMAIL</p>
  <a href=javascript:history.go(-1)><input type='submit' 
  class='button' value='Ulangi Lagi' name='submit'/></a>";}
		 
  
  elseif (empty($pesan)){
  echo "<p>Anda belum mengisikan PESAN</p>
  <a href=javascript:history.go(-1)><input type='submit' 
  class='button' value='Ulangi Lagi' name='submit'/></a>";}
  
  else{
  function antiinjection($data){
  $filter_sql = mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
  return $filter_sql;}

  $nama = antiinjection($_POST['nama']);
  $email = antiinjection($_POST['email']);
  $pesan = antiinjection($_POST['pesan']);
  $kota = antiinjection($_POST['kota']);

  if(!empty($_POST['kode'])){
  if($_POST['kode']==$_SESSION['captcha_session']){

  // Mengatasi input komentar tanpa spasi
  $split_text = explode(" ",$pesan);
  $split_count = count($split_text);
  $max = 57;

  for($i = 0; $i <= $split_count; $i++){
  if(strlen($split_text[$i]) >= $max){
  for($j = 0; $j <= strlen($split_text[$i]); $j++){
  $char[$j] = substr($split_text[$i],$j,1);
  if(($j % $max == 0) && ($j != 0)){
  $v_text .= $char[$j] . ' ';
  }else{
  $v_text .= $char[$j]; }}
  }else{
  $v_text .= " " . $split_text[$i] . " ";}}



  $sql = mysql_query("INSERT INTO testimonial(nama,
                                   email,
                                   kota,
                                   pesan,
                                   jam,
                                   tanggal) 
                        VALUES('$_POST[nama]',
                               '$_POST[email]',
                               '$_POST[kota]',
                              '$v_text',
                               '$jam_sekarang',
                               '$tgl_sekarang')");
 
  echo "<h4>Terima Kasih</h4>
      <p>Atas testimonial anda di $anekaweb[nama_website], kami segera merespon pesan anda.</p>
   <img src='$f[folder]/img/load.gif' width='200' height='15'/>
   <meta http-equiv='refresh' content='2; url=index.php'>";
   
   
   $kepada = "$anekaweb[email]"; 
   $judul = "Ada Testimonial di $anekaweb[nama_website]";
   $pesan = "Baru saja ada yang kirim testimoni di $anekaweb[nama_website]\n"; 
   $pesan .= "Cek Administrator: $anekaweb[url]/editweb"; 
   mail($kepada,$judul,$pesan,"From: $anekaweb[email]\n Content-type:text/html\r\n"); }
   
  
  else{
  echo "<p>Kode yang Anda masukkan tidak cocok !</p>
  <a href=javascript:history.go(-1) class='contactForm'>
  <input type='submit' class='button' value='Ulangi Lagi' name='submit'/></a><br/>";}}
  
  else{
  echo "<p>Anda belum memasukkan kode</p>
  <a href=javascript:history.go(-1)><input type='submit' 
  class='button' value='Ulangi Lagi' name='submit'/></a>";}}
     
		  
  ?>
</div>
          </div>
      
      
    <?php include "$f[folder]/modul/sidebar/sidebar-kontak.php";?>
        </div>
      </div>
    </div>
  </section>
  <div id="push"></div>
</div>