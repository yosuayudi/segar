      <section id="content">
      <div class="container top">
      
      
    <?php
function antiinjection($data){
  $filter_sql = mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
  return $filter_sql;
}

$valid_mail = "^([._a-z0-9-]+[._a-z0-9-]*)@(([a-z0-9-]+\.)*([a-z0-9-]+)(\.[a-z]{2,3}))$";
$nama_kustomer = antiinjection($_POST[nama_kustomer]);
$alamat = antiinjection($_POST[alamat]);
$telpon = antiinjection($_POST[telpon]);
$email = antiinjection($_POST[email]);
$kode_pos = antiinjection($_POST[kode_pos]);
$propinsi = antiinjection($_POST[propinsi]);
$kota = antiinjection($_POST[kota]);
$kode = antiinjection($_POST[kode]);
$username = str_replace(" ","",substr(strtolower($nama_kustomer), 0, 6));
$rand = rand(000000,999999);
$pass = substr(md5($rand),0 , 6);
$password = md5($pass);


$iden=mysql_fetch_array(mysql_query("SELECT * FROM identitas"));

$login=mysql_query("SELECT username FROM kustomer WHERE username='$username' OR email='$email'");
$ketemu=mysql_num_rows($login);
if($ketemu!=0){
echo "<div class='row'>
	  <div class='span9' id='column_right'>
	  <div class='aligncenter'>
	  <div class='button button-3x'><i class='icon-comment'></i></div>
	  <p style='font-size:22px;'><strong>PENDAFTARAN ANGGOTA GAGAL!</strong></p>
	  <p style='font-size:18px;'> Username <b>$username</b> atau email <b>$email</b> sudah terdaftar sebelumnya.</p>
	  <p style='font-size:18px;'>Silahkan mendaftarkan akun baru.</p>
	  <a href='javascript: window.history.go(-1)' class='button'><span>Ulangi Lagi</span></a>
	  <br>
	  <br>
  	  </div>
	  </div>";
}
elseif($nama_kustomer == ''){
echo "<div class='row'>
	  <div class='span9' id='column_right'>
	  <div class='aligncenter'>
	  <div class='button button-3x'><i class='icon-comment'></i></div>
	  <p style='font-size:22px;'><strong>PENDAFTARAN ANGGOTA GAGAL!</strong></p>
	  <p style='font-size:18px;'>Anda belum mengisi Nama lengkap.</p>
	  <a href='javascript: window.history.go(-1)' class='button'><span>Ulangi Lagi</span></a>
	  <br>
	  <br>
  	  </div>
	  </div>";
}
elseif($alamat == ''){
echo "<div class='row'>
	  <div class='span9' id='column_right'>
	  <div class='aligncenter'>
	  <div class='button button-3x'><i class='icon-comment'></i></div>
	  <p style='font-size:22px;'><strong>PENDAFTARAN ANGGOTA GAGAL!</strong></p>
	  <p style='font-size:18px;'>Anda belum mengisi Alamat lengkap.</p>
	  <a href='javascript: window.history.go(-1)' class='button'><span>Ulangi Lagi</span></a>
	  <br>
	  <br>
  	  </div>
	  </div>";
}

elseif($kode_pos == ''){
echo "<div class='row'>
	  <div class='span9' id='column_right'>
	  <div class='aligncenter'>
	  <div class='button button-3x'><i class='icon-comment'></i></div>
	  <p style='font-size:22px;'><strong>PENDAFTARAN ANGGOTA GAGAL!</strong></p>
	  <p style='font-size:18px;'>Anda belum mengisi Kodepos.</p>
	  <a href='javascript: window.history.go(-1)' class='button'><span>Ulangi Lagi</span></a>
	  <br>
	  <br>
  	  </div>
	  </div>";
}

elseif($telpon == ''){
echo "<div class='row'>
	  <div class='span9' id='column_right'>
	  <div class='aligncenter'>
	  <div class='button button-3x'><i class='icon-comment'></i></div>
	  <p style='font-size:22px;'><strong>PENDAFTARAN ANGGOTA GAGAL!</strong></p>
	  <p style='font-size:18px;'>Anda belum mengisi No. Telpon.</p>
	  <a href='javascript: window.history.go(-1)' class='button'><span>Ulangi Lagi</span></a>
	  <br>
	  <br>
  	  </div>
	  </div>";
}

elseif($email == ''){
echo "<div class='row'>
	  <div class='span9' id='column_right'>
	  <div class='aligncenter'>
	  <div class='button button-3x'><i class='icon-comment'></i></div>
	  <p style='font-size:22px;'><strong>PENDAFTARAN ANGGOTA GAGAL!</strong></p>
	  <p style='font-size:18px;'>Anda belum mengisi Email.</p>
	  <a href='javascript: window.history.go(-1)' class='button'><span>Ulangi Lagi</span></a>
	  <br>
	  <br>
  	  </div>
	  </div>";
}

elseif(!eregi($valid_mail, $email)){
echo "<div class='row'>
	  <div class='span9' id='column_right'>
	  <div class='aligncenter'>
	  <div class='button button-3x'><i class='icon-comment'></i></div>
	  <p style='font-size:22px;'><strong>PENDAFTARAN ANGGOTA GAGAL!</strong></p>
	  <p style='font-size:18px;'>Email yang anda masukan tidak valid.</p>
	  <a href='javascript: window.history.go(-1)' class='button'><span>Ulangi Lagi</span></a>
	  <br>
	  <br>
  	  </div>
	  </div>";
}

elseif($propinsi == ''){
echo "<div class='row'>
	  <div class='span9' id='column_right'>
	  <div class='aligncenter'>
	  <div class='button button-3x'><i class='icon-comment'></i></div>
	  <p style='font-size:22px;'><strong>PENDAFTARAN ANGGOTA GAGAL!</strong></p>
	  <p style='font-size:18px;'>Anda belum mengisi Propinsi.</p>
	  <a href='javascript: window.history.go(-1)' class='button'><span>Ulangi Lagi</span></a>
	  <br>
	  <br>
  	  </div>
	  </div>";
}
elseif($kota == ''){
echo "<div class='row'>
	  <div class='span9' id='column_right'>
	  <div class='aligncenter'>
	  <div class='button button-3x'><i class='icon-comment'></i></div>
	  <p style='font-size:22px;'><strong>PENDAFTARAN ANGGOTA GAGAL!</strong></p>
	  <p style='font-size:18px;'>Anda belum mengisi Kota.</p>
	  <a href='javascript: window.history.go(-1)' class='button'><span>Ulangi Lagi</span></a>
	  <br>
	  <br>
  	  </div>
	  </div>";
}

elseif($kode!=$_SESSION['captcha_session']){
echo "<div class='row'>
	  <div class='span9' id='column_right'>
	  <div class='aligncenter'>
	  <div class='button button-3x'><i class='icon-comment'></i></div>
	  <p style='font-size:22px;'><strong>PENDAFTARAN ANGGOTA GAGAL!</strong></p>
	  <p style='font-size:18px;'>Kode yang Anda masukkan tidak cocok.</p>
	  <a href='javascript: window.history.go(-1)' class='button'><span>Ulangi Lagi</span></a>
	  <br>
	  <br>
  	  </div>
	  </div>";
} else {

    if ($_POST[kota]=='lainnya'){                           
       $query="INSERT INTO kustomer(username,
                                 password,
                                 nama_kustomer,
                                 alamat,
                                 kode_pos,
                                 propinsi,
                                 kota,
								 jam,
								 tanggal,
								 hari,
                                 email, 
                                 telpon) 
                           VALUES('$username',
                                '$password',
                                '$nama_kustomer',
                                '$_POST[alamat]',
                                '$_POST[kode_pos]',
                                '$_POST[propinsi]',
                                '$_POST[kota]',
                                '$_POST[email]',
							    '$jam_sekarang',
							    '$tgl_sekarang',
							    '$hari_ini',
                                '$_POST[telpon]')";
    }
    else{
       $query="INSERT INTO kustomer(username,
                                 password,
                                 nama_kustomer,
                                 alamat,
                                 kode_pos,
                                 propinsi,
                                 kota,
								 jam,
								 tanggal,
								 hari,
                                 email, 
                                 telpon) 
                           VALUES('$username',
                                '$password',
                                '$nama_kustomer',
                                '$_POST[alamat]',
                                '$_POST[kode_pos]',
                                '$_POST[propinsi]',
                                '$_POST[kota]',
							    '$jam_sekarang',
							    '$tgl_sekarang',
							    '$hari_ini',
                                '$_POST[email]',
                                '$_POST[telpon]')";
    }
    mysql_query($query);
	echo "<div class='row'>
	  <div class='span9' id='column_right'>
	  <div class='aligncenter'>
	  <div class='button button-3x'><i class='icon-comment'></i></div>
	  <p style='font-size:22px;'><strong>PENDAFTARAN ANGGOTA BERHASIL!</strong></p>
	  <p style='font-size:18px;'>Username dan Password anda telah kami kirimkan ke email <b>$email</b></p>
	  <br>
	  <br>
  	  </div>
	  </div>";
	include "$f[folder]/modul/sidebar/sidebar.php";
$kepada   = $_POST[email];
$subject = ".:: Pendaftaran Anggota $iden[nama_website] ::.";
$pesan = "Terima kasih anda telah bergabung di $iden[nama_website], dibawah ini adalah rincian dari akun anda :<br>
<p><table>
<tr><td width=60>Username</td><td>: $username</td></tr>
<tr><td>Password</td><td>: $pass</td></tr>
<tr><td>Nama lengkap</td><td>: $nama_kustomer</td></tr>
<tr><td>Alamat lengkap</td><td>: $alamat</td></tr>
<tr><td>No. telpon</td><td>: $telpon</td></tr>
<tr><td>Email</td><td>: $email</td></tr>
<tr><td>Kota</td><td>: $kota</td></tr>
</table></p><br><br>
Silahkan melakukan login untuk mengganti username dan password Anda : $iden[url]/login.html";

$dari = "From: $iden[nama_website] <".$iden[email].">\n" . 
$dari .= "Content-type: text/html \r\n";
//mail($kepada, $subject, $pesan, $dari);
include "library/class.phpmailer.php";
$mail = new PHPMailer; 
$mail->IsSMTP();
$mail->Host = 'anekaweb.com'; //hostname masing-masing provider email 
$mail->SMTPDebug = 1;
$mail->Port = 25;
$mail->SMTPAuth = true;
$mail->Username = 'email'; //user email 
$mail->Password = 'password'; //password email 
$mail->SetFrom('email', $iden[nama_website]); //set email pengirim
$mail->Subject = $subject; //subyek email 
$mail->AddAddress($kepada, $email); //tujuan email
$mail->MsgHTML($pesan);
$mail->Send();
}


?>
           
      
     <?php include "$f[folder]/modul/sidebar/sidebar.php";?> 
    </div>
    </div>
    </div>
    </div>
                