      <section id="content">
      <div class="container top">
      
      
    <?php       
	   
      if($_SERVER['REQUEST_METHOD']=='POST'){
      // Cek email kustomer di database
      $cek_email=mysql_num_rows(mysql_query("SELECT email FROM kustomer WHERE email='$_POST[email]'"));
      // Kalau email tidak ditemukan
      if ($cek_email == 0){
echo "<div class='row'>
	  <div class='span9' id='column_right'>
	  <div class='aligncenter'>
	  <div class='button button-3x'><i class='icon-comment'></i></div>
	  <p style='font-size:22px;'><strong>Permintaan Password Baru</strong></p>
	  <p style='font-size:18px;'> <strong>Email $_POST[email] tidak terdaftar pada database kami.</strong></p>
	  <a href='javascript:history.go(-1)' class='button'><span>Ulangi Lagi</span></a>
	  <br>
	  <br>
  	  </div>
	  </div>";
      }
      else{
      $password_baru = substr(md5(uniqid(rand(),1)),3,10);
    
      // ganti password kustomer dengan password yang baru (reset password)
      $query=mysql_query("update kustomer set password=md5('$password_baru') where email='$_POST[email]'");
    
      // dapatkan email_pengelola dari database
      $anekaweb=mysql_fetch_array(mysql_query("SELECT * FROM identitas"));
     
      $kepada="$_POST[email]";
      $subjek="Password Baru $anekaweb[email]";
      $pesan="Password Anda yang baru adalah <b>$password_baru</b>";
      // Kirim email dalam format HTML
      $dari = "From: $anekaweb[nama_website] <".$anekaweb[email].">\n" . 
      $dari .= "Content-type: text/html\r\n";
    
      // Kirim password ke email kustomer
      //mail($kepada,$subjek,$pesan,$dari);
	  
	  include "library/class.phpmailer.php";
$mail = new PHPMailer; 
$mail->IsSMTP();
$mail->Host = 'anekaweb.com'; //hostname masing-masing provider email 
$mail->SMTPDebug = 1;
$mail->Port = 25;
$mail->SMTPAuth = true;
$mail->Username = 'info@anekaweb.com'; //user email 
$mail->Password = '1nf02016W3b'; //password email 
$mail->SetFrom('info@anekaweb.com', $iden[nama_website]); //set email pengirim
$mail->Subject = $subject; //subyek email 
$mail->AddAddress($kepada, ' '); //tujuan email
$mail->MsgHTML($pesan);
$mail->Send();
      
echo "<div class='row'>
	  <div class='span9' id='column_right'>
	  <div class='aligncenter'>
	  <div class='button button-3x'><i class='icon-comment'></i></div>
	  <p style='font-size:22px;'><strong>Permintaan Password Baru</strong></p>
	  <p style='font-size:18px;'> <strong>Password telah dikirim ke email $_POST[email]</strong></p>
	  <p style='font-size:18px;'>Silahkan cek email Anda. Selanjutnya Anda dapat login menggunakan password baru.</p>
	  <br>
	  <br>
  	  </div>
	  </div>";
    }
    }
    ?>
           
      
     <?php include "$f[folder]/modul/sidebar/sidebar.php";?> 
    </div>
    </div>
                