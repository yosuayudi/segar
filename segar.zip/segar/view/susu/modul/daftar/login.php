<section id="content">
    <div class="container top">
    <div class="content_top">
    <div class="breadcrumbs"><?php include "anekawebconfig/breadcrumb.php"; ?></div>
    </div>
      <div class="row">
        <div class="span12">
          <div class="wrapper">
            <h2 class="nopadding">Login atau buat akun baru</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="span6">
          <div class="box-wrapper">
            <div class="inside min-height">
            <?php $anekaweb=mysql_fetch_array(mysql_query("SELECT * FROM identitas")); ?>
              <h4>PELANGGAN BARU</h4>
              <p>Dengan membuat akun di <?php echo "$anekaweb[nama_website]";?>, Anda dapat melakukan proses belanja cepat, menyimpan beberapa alamat pengiriman dan mengetahui proses pengiriman produk serta banyak kemudahan lainnya. Anda dipersilakan untuk mendaftar akun sebagai pelanggan baru di <?php echo "$anekaweb[nama_website]";?>! </p>
            </div>
            <div class="line"></div>
            <div class="inside">
              <div class="wrapper">
                <div class="pull-right"><a href="daftar.html" class="button">Daftar</a></div>
              </div>
            </div>
          </div>
        </div>
        <div class="span6">
          <div class="box-wrapper">
            <div class="inside min-height">
              <h4>PELANGGAN TERDAFTAR</h4>
              <p>Apabila anda sudah memiliki akun silakan login.</p>
              <form action="member/cek_login.php" method="post" class="margin-2" name="form2">
                <p>Username *</p>
                <input required type="text" name="username" id="textfield" class="input-xlarge">
                <p>Password *</p>
                <input required type="password" name="password" id="textfield2" class="input-xlarge">
            </div>
            <div class="line"></div>
            <div class="inside">
              <div class="wrapper">
                <div class="pull-left margin-2"><a href="lupa-password.html" class="custom_color">Lupa Password?</a></div>
                <div class="pull-right"><input type="submit" class="button" value="Login" /></div>
              </div>
            </div>
               </form>
               
          </div>
        </div>
      </div>
    </div>
  </section>
  <div id="push"></div>
</div>