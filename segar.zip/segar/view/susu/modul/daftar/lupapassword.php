      <section id="content">
      <div class="container top">
      <div class="content_top">
    <div class="breadcrumbs"><?php include "anekawebconfig/breadcrumb.php"; ?></div>
    </div>
      <div class="row">
      <div class="span9" id="column_right">
      <div class="wrapper">
      <h2 class="nopadding">Lupa Password</h2>
      </div>
      
    <div class="row">
    <div class="span6">
    <div class="box-wrapper">
    <div class="inside min-height">
    <form action="kirim-password.html" method="post" name="lupapassword">
    <p>Masukan Email Anda:</p>
    <input required type="text" class="input-xlarge" name="email" />
    </div>
    <div class="line"></div>
    <div class="inside">
    <div class="wrapper">
    <div class="pull-right">
    <input type="submit" class="button" value="Kirim Password"></div>
    </div>
    </div>
    </form>
    </div>
    </div>
    </div>
    </div>
    
    <?php include "$f[folder]/modul/sidebar/sidebar.php";?>
    </div>
    </div>
                