<section id="content">
    <div class="container top">
    
    <div class="content_top">
    <div class="breadcrumbs"><?php include "anekawebconfig/breadcrumb.php"; ?></div>
    </div>
      <div class="row">
        <div class="span12">
          <div class="wrapper">
            <h2 class="nopadding">Login atau buat akun baru</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="span6">
          <div class="box-wrapper">
            <div class="inside min-height">
              <h4>PELANGGAN BARU</h4>
              <p>Isi semua data yang bertanda *</p><br/>
			  <form name="form" action="pendaftaran.html" method="post" onSubmit=\"return validasi(this)\">
                <p>Nama Lengkap *</p>
                <input required type="text" name="nama_kustomer" id="textfield" class="input-xlarge">
                <p>Alamat *</p>
                <input required type="text" name="alamat" id="textfield" class="input-xlarge">
                 <p>Kode Pos *</p>
                <input required type="text" name="kode_pos" id="textfield" class="input-xlarge">
                <p>No. Tlp/Hp *</p>
                <input required type="text" name="telpon" id="textfield" class="input-xlarge">
                <p>Email *</p>
                <input required type="text" name="email" id="textfield" class="input-xlarge">
                <p>Propinsi *</p>
                <input required type="text" name="propinsi" id="textfield" class="input-xlarge">
                <p>Kota *</p>
                <div class="select_wrapper fullwidth">
                <select name="kota" class="custom">
				<option required value="" selected>- Pilih Kota -</option>
				<?php
                 $tampil=mysql_query("SELECT * FROM kota ORDER BY nama_kota");
                  while($r=mysql_fetch_array($tampil)){
           echo "<option value=$r[nama_kota]>$r[nama_kota]</option>";
                }
           echo "<option value='lainnya'>- Lainnya -</option></select>";
                ?>
                </div>
            <p>Kode *</p>
            
            <p> <img src="captcha/captcha.php?rand=<?php echo rand(); ?>" id="captchaimg" ></p>
            <input required type="text" name="kode" class="input-small">
            <p>huruf tidak ke baca? klik <a href='javascript: refreshCaptcha();'>disini</a> refresh</p></div>
              
            <div class="line"></div>
            <div class="inside">
              <div class="wrapper">
                <div class="pull-right"><input type="submit" class="button" value="Daftar" /></div>
              </div>
            </div>
          </div>
        </div>
        
               </form>
               
        <div class="span6">
          <div class="box-wrapper">
            <div class="inside min-height">
              <h4>PELANGGAN TERDAFTAR</h4>
              <p>Apabila anda sudah memiliki akun silakan login.</p>
              <form action="member/cek_login.php?lf=selesaibelanja" method="post" class="margin-2" name="form2" onSubmit=\"return validasi2(this)\">
                <p>Username *</p>
                <input required type="text" name="username" id="textfield" class="input-xlarge">
                <p>Password *</p>
                <input required type="password" name="password" id="textfield2" class="input-xlarge">
            </div>
            <div class="line"></div>
            <div class="inside">
              <div class="wrapper">
                <div class="pull-left margin-2"><a href="lupa-password.html" class="custom_color">Lupa Password?</a></div>
                <div class="pull-right"><input type="submit" class="button" value="Login" /></div>
              </div>
            </div>
               </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <div id="push"></div>
</div>