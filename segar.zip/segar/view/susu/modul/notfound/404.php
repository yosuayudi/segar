<section id="content">
  <div class="container top">
    <div class="row">
      <div class="span9" id="column_right">
        <div class="aligncenter">
          <div class="button button-3x"><i class="icon-comment"></i></div>
          <p style="font-size:28px;"><strong>404</strong></p>
          <p style="font-size:18px;"> Page not found...</p>
          <p>Maaf halaman yang anda cari tidak dapat ditemukan. Atau telah dihapus. <br>
<br>
<br>
      </div>
       </div>
        
    <?php include "$f[folder]/modul/sidebar/sidebar.php";?>
        
        
        </div>
      </div>
    </div>
  </section>
  <div id="push"></div>
</div>