<?php
include "../config/koneksi.php";
include "../config/library.php";
include "../config/fungsi_indotgl.php";
include "../config/fungsi_combobox.php";
include "../config/class_paging.php";
include "../config/fungsi_rupiah.php";

// Bagian Home
if ($_GET[module]=='home'){
  echo "<h2>Selamat Datang</h2>
          <p>Hai <b>$_SESSION[namalengkap]</b>, selamat datang di halaman Administrator website Detikcom.<br> Silahkan klik menu pilihan yang berada 
          di sebelah kiri untuk mengelola content website. </p>
          <p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>
          <p align=right>Login : $hari_ini, ";
  echo tgl_indo(date("Y m d")); 
  echo " | "; 
  echo date("H:i:s");
  echo " WIB</p>";
}

// Bagian Profil
elseif ($_GET[module]=='profil'){
  include "modul/mod_profil/profil.php";
}

//Bagian Tampil Order
elseif ($_GET[module]=='tampilorder'){
  include "modul/mod_tampil_order/tampil_order.php";
}

//Bagian Afiliasi
elseif ($_GET[module]=='afiliasi'){
  include "modul/mod_afiliasi/afiliasi.php";
}

//Bagian Afiliasi
elseif ($_GET[module]=='banner'){
  include "modul/mod_banner/banner.php";
}

// Apabila modul tidak ditemukan
else{
  echo "<p><b>MODUL BELUM ADA ATAU BELUM LENGKAP</b></p>";
}
?>
