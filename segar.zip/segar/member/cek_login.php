<?php
include "../config/koneksi.php";
$username = $_POST['username'];
$pass     = md5($_POST['password']);

$login=mysql_query("SELECT * FROM kustomer WHERE username='$username' AND password='$pass' AND blokir='N'");
$ketemu=mysql_num_rows($login);
$r=mysql_fetch_array($login);

// Apabila username dan password ditemukan
if ($ketemu > 0){
  session_start();
  

  $_SESSION[member_namauser]     = $r[username];
  $_SESSION[member_namalengkap]  = $r[nama_kustomer];
  $_SESSION[member_passuser]     = $r[password];
  $_SESSION[member_id]           = $r[id_kustomer];
  
  
  header('location:../media.php?module=profil');
  }

else{
 echo"<script>alert('Login gagal.Username atau password anda tidak benar. Atau akun anda sedang diblokir.')</script>";
	echo"<script>document.location.href='javascript:history.go(-1)';</script>";
	
}
?>

