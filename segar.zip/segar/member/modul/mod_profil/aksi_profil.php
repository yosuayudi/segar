<?php

session_start();
include "../../../config/koneksi.php";

$module=$_GET[module];
$act=$_GET[act];

//delete user
if ($module=='profil' AND $act=='delete'){
  mysql_query("DELETE FROM kustomer WHERE id_kustomer =$_SESSION[member_id]");
  
  if ($_SESSION[leveluser] == 'admin'){
	header('location:../../media.php?module='.$module);
  }
  else{
	session_start();
	session_destroy();
	header('location:../../../index.php');
  }
}

// Update user
else if ($module=='profil' AND $act=='update'){
 if (empty($_POST[password])) {
    mysql_query("UPDATE kustomer SET nama_kustomer = '$_POST[nama_kustomer]',
								     alamat		   = '$_POST[alamat]',
                                     kode_pos	   = '$_POST[kode_pos]',
								     propinsi	   = '$_POST[propinsi]',
								     kota		   = '$_POST[kota]',
                                     email         = '$_POST[email]',
                                     blokir        = '$_POST[blokir]',  
                                     telpon        = '$_POST[telpon]' 
                              WHERE  id_kustomer   = $_SESSION[member_id]");
  }
  // Apabila password diubah
  else{
    $pass=md5($_POST[password]);
    mysql_query("UPDATE kustomer SET password      = '$pass',
                                     nama_kustomer = '$_POST[nama_kustomer]',
								     alamat		   = '$_POST[alamat]',
                                     kode_pos	   = '$_POST[kode_pos]',
								     propinsi	   = '$_POST[propinsi]',
								     kota		   = '$_POST[kota]',
                                     email         = '$_POST[email]',  
                                     blokir        = '$_POST[blokir]',  
                                     telpon        = '$_POST[telpon]'  
                               WHERE id_kustomer   = $_SESSION[member_id]");
  }
   header('location:../../../media.php?module='.$module);
}

?>
