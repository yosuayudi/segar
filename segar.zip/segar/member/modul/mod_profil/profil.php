<?php
//Mencegah direct akses
$cek=mysql_query("SELECT COUNT(*) AS cek FROM kustomer WHERE id_kustomer=$_SESSION[member_id]");
$ada=mysql_fetch_array($cek);

if ($ada[cek] == 0){ 
	echo"<script>window.location='index.php'</script>";
}


$aksi="member/modul/mod_profil/aksi_profil.php";
switch($_GET[act]){
  // Tampil User
  default:
      $tampil=mysql_query("SELECT * FROM kustomer 
                           WHERE id_kustomer=$_SESSION[member_id]");
      $r=mysql_fetch_array($tampil);
	  
echo "<section id='content'>
      <div class='container top'>
      <div class='content_top'>
      <div class='breadcrumbs'>";
      include 'anekawebconfig/breadcrumb.php';
echo "</div>
      </div>
	  
	  <div class='row'>
      <div class='span9' id='column_right'>
	  <h2>DATA PROFIl ANDA</h2> 
	  <div class='box-wrapper'>
      <div class='inside min-height'>
      <p> <a href=?module=profil&act=edituser&id=$r[id_kustomer] class='button'>Edit Profil</a></p>
      ";
echo"<table class='table shopping-cart-table'>
	  <tr><td width='80'><b>Username</b> </td><td> $r[username]</td></tr>
	  <tr><td width='80'><b>Nama Lengkap</b> </td><td> $r[nama_kustomer] </td></tr>
	  <tr><td width='80'><b>Alamat</b></td><td> $r[alamat] </td></tr>
	  <tr><td width='80'><b>Kode Pos</b></td><td> $r[kode_pos]</td></tr>
	  <tr><td width='80'><b>Propinsi</b></td><td> $r[propinsi]</td></tr>
	  <tr><td width='80'><b>Kota</b></td><td> $r[kota]</td></tr>
	  <tr><td width='80'><b>Email</b></td><td> $r[email]</td></tr>
	  <tr><td width='80'><b>No Tlp/HP</b></td><td> $r[telpon]</td></tr>
	  </table>
	 
	  
	  
	  </div>
	  </div>
	  </div>";
     include "$f[folder]/modul/sidebar/sidebar-akun.php";
echo"</div>
    </div>
    </div>
    </section>
    <div id='push'></div>
    </div>";
	
     break;
  
  case "edituser":
	$edit=mysql_query("SELECT * FROM kustomer WHERE id_kustomer=$_SESSION[member_id]");
    $r=mysql_fetch_array($edit);
	
echo "<section id='content'>
      <div class='container top'>
      <div class='content_top'>
      <div class='breadcrumbs'>";
      include 'anekawebconfig/breadcrumb.php';
echo "</div>
      </div>
	  
	  <div class='row'>
      <div class='span9' id='column_right'>
	  <h2>EDIT PROFIL</h2> 
	  <div class='box-wrapper'>
      <div class='inside min-height'>";
	  
	  
echo"<form method=POST action='$aksi?module=profil&act=update&id=$r[id_kustomer]
	  <input type=hidden name=id value='$r[id_kustomer]'>
	  
	  
	  <p>Username: <span class='req'>*</span></p>
	  <input name='username' type='text' id='username' class='input-xlarge' value='$r[username]' disabled>
	  
	  
	  <p>Password: <span class='req'>*</span></p>
	  <input name='password' type='text' id='password' class='input-xlarge'>
	  
	  
	  <p>Nama Lengkap: <span class='req'>*</span></p>
	  <input name='nama_kustomer' type='text' id='nama_kustomer' value='$r[nama_kustomer]' class='input-xlarge'>
	  
	  
	  <p>Email: <span class='req'>*</span></p>
	  <input name='email' type='text' id='email' value='$r[email]' class='input-xlarge'>
	  
	  
	  <p>No. Telepon/HP: <span class='req'>*</span></p>
	  <input name='telpon' type='text' id='telpon' value='$r[telpon]' class='input-xlarge'>
	
	  <p>Kode Pos: <span class='req'>*</span></p>
	  <input name='kode_pos' type='text' id='kode_pos' value='$r[kode_pos]' class='input-xlarge'>
	  
	  
	  <p>Propinsi: <span class='req'>*</span></p>
	  <input name='propinsi' type='text' id='propinsi' value='$r[propinsi]' class='input-xlarge'>
	  
	  
	  <div class='select_wrapper fullwidth'>
	  Kota Tujuan: <span class='req'>*</span>
	   <select name='kota' class='custom'><option value='' selected>- Pilih Kota -</option>";
	  //isi combobox
	  $tampil=mysql_query("SELECT * FROM kota ORDER BY nama_kota");
	  while($s=mysql_fetch_array($tampil)){
echo "<option value=$s[nama_kota]>$s[nama_kota]</option>";
	  }
	  //Cek kota
	  $cekkotaquery=mysql_query("SELECT * FROM kota WHERE nama_kota='$r[kota]'");
	  $cekkota=mysql_num_rows($cekkotaquery);
	  if ($cekkota == 0){
echo "<option value='lainnya' selected>- Lainnya -</option>";
	  $isikota=$r[kota];
	  }
	  else{
echo "<option value=$r[kota] selected>$r[kota]</option>
	  <option value='lainnya'>- Lainnya -</option>";
	  $isikota='';
	  }
echo "</select>
	  </div>
	
	  <p>Alamat Lengkap: <span class='req'>*</span></p>
	  <textarea name='alamat' cols='35' rows='2' class='input-xlarge' id='alamat'>$r[alamat]</textarea>
	  
	  <p><input type=hidden name='blokir' value='N'></p>
	  
	 </div>
	   <div class='line'></div>
	  <div class='inside'>
	  <div class='wrapper'>
	  
	  <div class='row'>
	  <div class='span4'>
	  <input type=submit  class='button' value='Update'>
	  <a class='button' id=reset-validate-form href='?module=profil'>Batal</a>
	  </div>
	  
	  <div class='span4'>** Username tidak bisa diubah.<br>
	  * Apabila password tidak diubah, dikosongkan saja.</div></div></div>
	  
	  </form>
	 
	  
	  
	  </div>
	  </div>
	  </div>";
     include "$f[folder]/modul/sidebar/sidebar-akun.php";
echo"</div>
    </div>
    </div>
    </section>
    <div id='push'></div>
    </div>";      break;  
      }

?>
     