<?php
//Authentication
include "../../../config/authentication_kustomer.php";

session_start();
include "../../../config/koneksi.php";

$module=$_GET[module];
$act=$_GET[act];

// Update status order
if ($module=='konfirmasi' AND $act=='update'){
	$pembayaran='No Order : '.$_POST[noorder].'<br>Pembayaran Ke : '.$_POST[rekeningtujuan].'<br> Pada Tanggal : '.$_POST[tglbayar].'<br>Sebesar : '.$_POST[besarbayar].'<br>Dari : '.$_POST[namabank].'<br>No Rekening : '.$_POST[norekening].' Atas Nama : '.$_POST[nama];
	mysql_query("UPDATE orders SET pembayaran='$pembayaran' where id_orders='$_POST[noorder]'");
	header('location:../../../media.php?module=tampilorder');
}
?>
