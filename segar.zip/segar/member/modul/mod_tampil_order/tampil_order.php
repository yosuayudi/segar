<?php
//Mencegah direct akses
$cek=mysql_query("SELECT COUNT(*) AS cek FROM kustomer WHERE id_kustomer=$_SESSION[member_id]");
$ada=mysql_fetch_array($cek);

if ($ada[cek] == 0){ 
	echo"<script>window.location='index.php'</script>";
}


$aksi="member/modul/mod_tampil_order/aksi_tampil_order.php";
session_start();
$user=$_SESSION[member_id];
$resi = htmlentities($_POST['resi']);
switch($_GET[act]){
  // Tampil Order
    default:
	//untuk warna selang seling pada tabel
	$warnaGenap='#101010';
	$warnaGanjil='#020202';
	//$warnaGenap='#E1EFFF';
	//$warnaGanjil='#FFFFFF';
echo "<section id='content'>
      <div class='container top'>
      <div class='content_top'>
      <div class='breadcrumbs'>";
      include 'anekawebconfig/breadcrumb.php';
echo "</div>
      
      </div>
	  <div class='row'>
      <div class='span9' id='column_right'>
	  <h2>KONFIRMASI ORDER ANDA</h2>";
echo "<table class='table shopping-cart-table'>
	  <tr>
	  <th><strong>No.</strong></th>
	  <th class='aligncenter'><strong>Tgl. Order</strong></th>
	  <th class='aligncenter'><strong>Jam</strong></th>
	  <th class='aligncenter'><strong>Pembayaran</strong></th>
	  <th class='aligncenter'><strong>Status</strong></th>
	  <th class='aligncenter'><strong>No. Resi</strong></th>
	  <th class='aligncenter'><strong>Aksi</strong></th>
	  </tr> ";

	  $p      = new Paging;
	  $batas  = 10;
	  $posisi = $p->cariPosisi($batas);

	  $tampil = mysql_query("SELECT * FROM orders WHERE id_kustomer='$user' ORDER BY id_orders DESC LIMIT $posisi,$batas");
		
	  $no=1;
      while($r=mysql_fetch_array($tampil)){
		if ($r[status_order] == 'Dikirim'){
			$status='Dikirim Ke Alamat Akun Anda <br/>';}
		elseif($r[status_order] == 'Lunas'){
			$status='Pembayaran Lunas';}
		elseif($r[status_order] == 'Baru' AND $r[pembayaran]==''){
			$status='Segera Lakukan Pembayaran';}
		elseif($r[status_order] == 'Batal'){
			$status='Batal Tidak Ada konfirmasi Dalam Waktu 3 Hari';}
		elseif($r[status_order] == 'Baru' AND $r[pembayaran]!=''){
			$status='Pembayaran Sedang dikonfirmasi';}
		else{
			$status='';}
			
      $tanggal=tgl_indo($r[tgl_order]);
	  
	  if ($no % 2 == 0){
		$warna = $warnaGenap;}
	   else{
		$warna = $warnaGanjil;}
		
echo "<tr bgcolor='$warna'>
	  <td width='30' align='center'>$r[id_orders]</td>
	  <td width='90' align='center'>$tanggal</td>
	  <td width='50' align='center'>$r[jam_order]</td>
	  <td width='130' align='center'>$r[pembayaran]</td>
	  <td width='100' align='center'>$status</td>
	  <td width='85' align='center'>$r[resi]</td>
	  <td width='60' align='center'><a href=?module=tampilorder&act=detailorder&id=$r[id_orders]>Detail</a></td>
	  </tr>";
      $no++;
      }
echo "<br /></table><br />";

      $jmldata = mysql_num_rows(mysql_query("SELECT * FROM orders WHERE id_kustomer='$user'"));
      $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
      $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

echo "<div id=paging>Halaman : $linkHalaman</div>
       </div>";
	  
      include "$f[folder]/modul/sidebar/sidebar-akun.php";
echo "</div>
      </div>
      </div>
      </section>";
    break;
  
  //detail order  
  case "detailorder":
    $edit = mysql_query("SELECT * FROM orders, kustomer WHERE kustomer.id_kustomer=orders.id_kustomer AND id_orders='$_GET[id]' AND orders.id_kustomer='$user' ");
    $r    = mysql_fetch_array($edit);
	$tanggal=tgl_indo($r[tgl_order]);
	
	if ($r[status_order] == 'Dikirim'){
			$status='Dikirim Ke Alamat Akun Anda';}
		elseif($r[status_order] == 'Lunas'){
			$status='Pembayaran Lunas';}
		elseif($r[status_order] == 'Baru' AND $r[pembayaran]==''){
			$status='Segera Lakukan Pembayaran';}
		elseif($r[status_order] == 'Batal'){
			$status='Batal Tidak Ada konfirmasi Dalam Waktu 3 Hari';}
		elseif($r[status_order] == 'Baru' AND $r[pembayaran]!=''){
			$status='Pembayaran Sedang dikonfirmasi';}
		else{
		$status='';}
	
echo "<section id='content'>
      <div class='container top'>
      <div class='content_top'>
      <div class='breadcrumbs'>";
      include 'anekawebconfig/breadcrumb.php';
echo "</div>
      </div>
	  
	  <div class='row'>
      <div class='span9' id='column_right'>
	  <h2>DETAIL ORDER</h2>";
	
echo "<table class='table shopping-cart-table'>
	  <tr><td width='90' height='20'>No. Order</td><td> $r[id_orders]</td></tr>
	  <tr><td width='90' height='20'>Tgl. & Jam Order</td><td> $tanggal & $r[jam_order]</td></tr>
	  <tr><td width='90' height='20'>Pembayaran</td><td> $r[pembayaran]</td></tr>
	  <tr><td width='90' height='20'>Status Order</td><td> $status</td></tr>
	  </table><br/>";
	

  // tampilkan data kustomer untuk pengiriman
  if ($r[shipping]== 'akun'){
echo"<h2>INFORMASI BARANG DIKIRIM KE ALAMAT DIBAWAH INI</h2>";
echo "<table class='table shopping-cart-table'>
	  <tr><td width='90' height='20'>Dikirim ke Alamat</td><td> $r[alamat]</td></tr>
	  <tr><td width='90' height='20'>Kode Pos</td><td> $r[kode_pos]</td></tr>
	  <tr><td width='90' height='20'>Propinsi</td><td> $r[propinsi]</td></tr>
	  <tr><td width='90' height='20'>Kota</td><td> $r[kota]</td></tr>
	  </table>";
	  $kota=$r[kota];	
      }
      else{
echo"<h2>INFORMASI BARANG DIKIRIM KE ALAMAT DIBAWAH INI</h2>";
	 
echo "<table class='table shopping-cart-table'>
	  <tr><th colspan=2><b>Informasi Pengiriman</b> </th></tr>
	  <tr><td width='90' height='20'>Dikirim ke Alamat</td><td> $r[alamat]</td></tr>
	  <tr><td width='90' height='20'>Kode Pos</td><td>$r[kode_pos]</td></tr>
	  <tr><td width='90' height='20'>Propinsi</td><td> $r[propinsi]</td></tr>
	  <tr><td width='90' height='20'>Kota</td><td> $r[kota]</td></tr>
	  </table>";
	  $kota=$r[kota];
      }
      // tampilkan rincian produk yang di order
      $sql2=mysql_query("SELECT * FROM orders_detail, produk 
                     WHERE orders_detail.id_produk=produk.id_produk 
                     AND orders_detail.id_orders='$r[id_orders]'");
  
  echo"<h2>RINCIAN ORDER ANDA</h2>";
 echo "<table class='table shopping-cart-table'>
	  <tr>
	  <th><strong>Produk</strong></th>
	  <th><strong>Nama Produk</strong></th>
	  <th class='aligncenter'><strong>Jumlah</strong></th>
	  <th class='aligncenter'><strong>Berat</strong></th>
	  <th class='aligncenter'><strong>Keterangan</strong></th>
	  <th class='aligncenter'><strong>Harga</strong></th>
	  <th class='aligncenter'><strong>Sub Total</strong></th>
	  </tr>";
	  
      $total = '';
	  $totalberat = '';
	  $no=1;
      while($d=mysql_fetch_array($sql2)){
     // rumus untuk menghitung subtotal dan total		
     $subtotalberat = $d[berat] * $d[jumlah]; // total berat per item produk 
	 $totalberat  = $totalberat + $subtotalberat; // grand total berat all produk yang dibeli
	 $disc        = ($d[diskon]/100)*$d[harga];
	 $hargadisc   = number_format(($d[harga]-$disc),0,",",".");
	 $subtotal    = ($d[harga]-$disc) * $d[jumlah];
	 $total       = $total + $subtotal;  
	 $subtotal_rp = format_rupiah($subtotal);
	 $total_rp    = format_rupiah($total);
	 $harga       = format_rupiah($d[harga]);
			
echo "<tr>
		<td><center><img src='images/produk/small_$d[gambar]' border='0' width='40' height='35'/></center></td>
		<td><center>$d[nama_produk]</center></td>
		<td><center>$d[jumlah]</center></td>
		<td><center>$d[berat]/kg</center></td>
		<td><center>$d[keterangan]</center></td>
		<td><center>Rp. $hargadisc,-</center></td>
		<td><center>Rp. $subtotal_rp,-</center></td>
		</tr>
		</table>";
		$no++;
		}
		//Menghitung biaya pengiriman
		$grandtotal='';
		$ongkos=mysql_fetch_array(mysql_query("SELECT ongkos_kirim FROM kota WHERE nama_kota='$kota'"));
		
		$ongkoskirim1=$ongkos[ongkos_kirim];
		$totalberat = ceil($totalberat);
		$ongkoskirim = $ongkoskirim1 * $totalberat;
		
		$grandtotal    = $total + $ongkoskirim; 
		
		$ongkoskirim_rp = format_rupiah($ongkoskirim);
		$ongkoskirim1_rp = format_rupiah($ongkoskirim1); 
		$grandtotal_rp  = format_rupiah($grandtotal); 

			
echo "<div class='pull-right hidden-phone'>
      <div class='span-anekaweb1'>
	  <div class='box-wrapper'>
	  <div class='inside'>
	  <table class='table shopping-cart-table-total'>
	  <tr>
	  <th class='alignright'>Total :</th>
	  <th> Rp. $total_rp</th>
	  </tr>
	  <tr>";
	  if($totalberat!=0){ 
echo "<th class='alignright'>Ongkos Kirim Tujuan Kota Anda :</th>
	  <th> Rp. $ongkoskirim1_rp</th>
	  </tr>
	  <tr>
	  <th class='alignright'>Total Berat :</th>
	  <th>$totalberat/Kg</th>
	  </tr>
	  <tr>
	  <th class='alignright'>Total Ongkos Kirim :</th>
	  <th>Rp. $ongkoskirim_rp</th>
	  </tr>";
	  }
echo "<tr>
	  <td class='alignright'><h4>GRAND TOTAL :</h4></td>
	  <td><h4>Rp. $grandtotal_rp</h4></td>
	  </tr>
	  </table>
	  
	  <div class='line'></div>
	  <div class='inside'>
	  <div class='wrapper'>
	  <a href='media.php?module=tampilorder&act=konfirmasi&id=$r[id_orders]' class='button'>Konfirmasi Pembayaran</a>
	  </div>
	  </div>
	  
      </div>
      </div>
      </div>
      </div>
	  
	  </div>";
	  
      include "$f[folder]/modul/sidebar/sidebar-akun.php";
echo "</div>
      </div>
      </div>
      </section> ";
  break;  
	
	
//konfrimasi pembayaran
case "konfirmasi";
     //tampilkan order
     $sql=mysql_query("SELECT * FROM orders WHERE id_orders='$_GET[id]'");
     $r=mysql_fetch_array($sql);
  
     //mencegah melakukan konfirmasi ulang pada saat status order Lunas atau Dikirim
     if ($r[status_order]=='Lunas' OR $r[status_order]=='Dikirim'){
echo"<script>document.location.href='javascript:history.go(-1)'</script>";
	 exit;
     }
   
    // tampilkan rincian harga produk yang di order
    $sql2=mysql_query("SELECT * FROM orders_detail, produk 
                     WHERE orders_detail.id_produk=produk.id_produk 
                     AND orders_detail.id_orders='$_GET[id]'");
  
    while($s=mysql_fetch_array($sql2)){
	$subtotalberat = $s[berat] * $s[jumlah]; // total berat per item produk 
     $totalberat  = $totalberat + $subtotalberat; // grand total berat all produk yang dibeli
     $disc        = ($s[potongan]/100)*$s[harga];
     $hargadisc   = number_format(($r[harga]-$disc),0,",",".");
     $subtotal    = ($s[harga]-$disc) * $s[jumlah];
     $total       = $total + $subtotal;  
     $subtotal_rp = format_rupiah($subtotal);
     $total_rp    = format_rupiah($total);
     $harga       = format_rupiah($s[harga]);
    }
    //Tampil kota kustomer
    $sql3=mysql_query("SELECT * FROM kustomer WHERE id_kustomer='$r[id_kustomer]'");
    $r3=mysql_fetch_array($sql3);
    //Informasi Pengiriman
		if ($r[shipping] == 'akun'){
			$kota		= $r3[kota];
		}else{
			$kota		= $r[kota_kirim];}
			
    //Menghitung Biaya Pengiriman
	$grandtotal='';
	$ongkos=mysql_fetch_array(mysql_query("SELECT ongkos_kirim FROM kota WHERE nama_kota='$kota'"));
			 
	$ongkoskirim1=$ongkos[ongkos_kirim];
    $ongkoskirim = $ongkoskirim1 * $totalberat;
	$grandtotal    = $total + $ongkoskirim; 
    $ongkoskirim_rp = format_rupiah($ongkoskirim);
    $ongkoskirim1_rp = format_rupiah($ongkoskirim1); 
    $grandtotal_rp  = format_rupiah($grandtotal); 
	
	
     //mengisi combobox
    $pilihan_transfer = array('BCA No Rekening 7180178249 a/n Dedi Apriadi ', 'Mandiri No Rekening 1260005342075 a/n Dedi Apriadi');
    $transfer = '';
    foreach ($pilihan_transfer as $status) {
	$transfer .= "<option value=$status>$status</option>\r\n";
	}
  
echo "<section id='content'>
      <div class='container top'>
      <div class='content_top'>
      <div class='breadcrumbs'>";
      include 'anekawebconfig/breadcrumb.php';
echo "</div>
      </div>
	  
	  <div class='row'>
      <div class='span9' id='column_right'>
	  <h2>Konfirmasi Pembayaran</h2>
      <div class='box-wrapper'>
      <div class='inside min-height'>
	  <form method=POST action='$aksi?module=konfirmasi&act=update' class='margin-2'>
	
	  <h2>No Order :  <span class='req'>$_GET[id]</span></h2>
	  <input type=hidden name=noorder value='$_GET[id]'>
	  
	 
	  <p>Tanggal Pembayaran: <span class='req'>*</span></p>
	  <input type='text' name='tglbayar' class='input-xlarge'>
	  
	  <p>Pembayaran ke Bank: <span class='req'>*</span></p>
	  <div class='select_wrapper fullwidth'>
	  <select name='rekeningtujuan' class='custom'>$transfer</select>
	  </div>
	 
	  <p>Besar Pembayaran: <span class='req'>*</span></p>
	  <input type=text name=besarbayar value='Rp. $grandtotal_rp' class='input-xlarge'>
	 
	  <p>Nama Bank Transfer Anda: <span class='req'></span></p>
	  <input type='text' name='namabank' class='input-xlarge'>
	 
	  <p>No Rekening: <span class='req'>*</span></p>
	  <input type='text' name='norekening' class='input-xlarge'>
	  
	  
	  <p>Atas Nama: <span class='req'>*</span></p>
	  <input type='text' name='nama' class='input-xlarge'>
	  
	  
       </div>
	  <div class='line'></div>
	  <div class='inside'>
	  <div class='wrapper'>
	  <input class='button' type=submit value='Kirim'>
	  </div>
	  </div>
	  
	  </form></div></div>";
	  
      include "$f[folder]/modul/sidebar/sidebar-akun.php";
echo "</div>
      </div>
      </div>
      </section>";
	
}


?>
        
        
       