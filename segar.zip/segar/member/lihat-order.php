<?php
//authentication kustomer
$pathfile='config/authentication_kustomer.php';
if (file_exists($pathfile)){
	include "$pathfile";
}
else{
	include "../".$pathfile;
}

session_start();
echo "<section id='content'>
      <div class='container top'>
      <div class='content_top'>
      <div class='breadcrumbs'>";
      include 'anekawebconfig/breadcrumb.php';
echo "</div>
      
      </div>
	  <div class='row'>
      <div class='span9' id='column_right'>
	  <h2>ORDER ANDA</h2>
	  <div class='box-wrapper'>
	  <div class='inside'>";
	
	  // dapatkan data order 
	  $sql=mysql_query("SELECT * FROM orders WHERE id_kustomer=$_SESSION[member_id] 
	                             AND status_order='Baru' ORDER BY id_orders DESC LIMIT 3");
	  $count=mysql_num_rows($sql);
	
	  if ($count > 0 ){
echo "<p><strong>Data order anda sebagai berikut :</strong></p>";
		
	  while ($r=mysql_fetch_array($sql)){
	  //tampil data kustomer
	  $tampil=mysql_query("SELECT * FROM kustomer WHERE id_kustomer='$r[id_kustomer]'");
	  $r2=mysql_fetch_array($tampil);
			
echo"<p>Nomor Order : <b>$r[id_orders]</b>
      <font color=#000000> (Catat no order untuk konfirmasi pembayaran)</font></p> ";
echo"Tanggal Order : <b>$r[tgl_order]</b></div></div>";
			
echo "<div class='row'>
      <div class='span9' id='column_right'>
	  <h2>BARANG DI KIRIM KE ALAMAT</h2>";
	  
		if ($r[shipping]== 'akun'){
			  $alamat	= $r2[alamat];
			  $kodepos	= $r2[kode_pos];
			  $propinsi	= $r2[propinsi];
			  $kota		= $r2[kota];
		}
		else{
			$alamat		= $r[alamat];
			$kodepos	= $r[kode_pos];
			$propinsi	= $r[propinsi];
			$kota		= $r[kota];	
		}
echo "<table class='table shopping-cart-table'>
	  <tr><td width='80' height='20'><b>Alamat</b></td><td> $alamat</b></td></tr>
	  <tr><td width='80' height='20'><b>Kode Pos</b></td><td> $kodepos</td></tr>
	  <tr><td width='80' height='20'><b>Propinsi</b></td><td> $propinsi</td></tr>
	  <tr><td width='80' height='20'><b>kota</b></td><td> $kota</td></tr>
	  </table>";
			//menampilkan data order
			$daftarproduk=mysql_query("SELECT * FROM orders_detail,produk 
									  WHERE orders_detail.id_produk=produk.id_produk 
									  AND id_orders='$r[id_orders]'");
			
echo "<table class='table shopping-cart-table'>
	  <tr>
	  <th class='aligncenter'><strong>Produk</strong></th>
	  <th class='aligncenter'><strong>Nama Produk</strong></th>
	  <th class='aligncenter'><strong>Jumlah</strong></th>
	  <th class='aligncenter'><strong>Berat</strong></th>
	  <th class='aligncenter'><strong>Keterangan</strong></th>
	  <th class='aligncenter'><strong>Harga</strong></th>
	  <th class='aligncenter'><strong>Sub Total</strong></th>
	  </tr>";
	  
	    $total = '';
		$totalberat = '';
		$no=1;
		while ($d=mysql_fetch_array($daftarproduk)){
		
		$subtotalberat = $d[berat] * $d[jumlah]; // total berat per item produk 
		$totalberat  = $totalberat + $subtotalberat; // grand total berat all produk yang dibeli
		$disc        = ($d[diskon]/100)*$d[harga];
		$hargadisc   = number_format(($d[harga]-$disc),0,",",".");
		$subtotal    = ($d[harga]-$disc) * $d[jumlah];
		$total       = $total + $subtotal;  
		$subtotal_rp = format_rupiah($subtotal);
		$total_rp    = format_rupiah($total);
		$harga       = format_rupiah($d[harga]);
			
echo "<tr>
      <td><img src='images/produk/small_$d[gambar]' height='30' alt='$d[nama_produk]'></td>
      <td><span class='cart-col-name'></span><strong> <a href='produk-$d[id_produk]-$d[produk_seo].html'>$d[nama_produk]</a></strong></td>
      <td class='aligncenter'><strong>$d[jumlah]</strong></td>
	  <td class='aligncenter'><strong>$d[berat]/kg</strong></td>
	  <td class='aligncenter'><strong>$d[keterangan]</strong></td>
      <td class='aligncenter'><span class='cart-col-name'></span><strong>Rp. $hargadisc</strong></td>
      <td class='aligncenter'><span class='cart-col-name'></span><strong>Rp. $subtotal_rp</strong></td>
      </tr>
		</table>";
		$no++;
		}
		
		//Menghitung biaya pengiriman
		$grandtotal='';
		$ongkos=mysql_fetch_array(mysql_query("SELECT ongkos_kirim FROM kota WHERE nama_kota='$kota'"));
		
		
		$ongkoskirim1=$ongkos[ongkos_kirim];
		$totalberat = ceil($totalberat);
		$ongkoskirim = $ongkoskirim1 * $totalberat;
		
		$grandtotal    = $total + $ongkoskirim; 
		
		$ongkoskirim_rp = format_rupiah($ongkoskirim);
		$ongkoskirim1_rp = format_rupiah($ongkoskirim1); 
		$grandtotal_rp  = format_rupiah($grandtotal); 


	  
echo "<div class='row'>
      <div class='pull-left'>
      <div class='span-anekaweb1'>
	  <div class='box-wrapper'>
	  <div class='inside'>
	  <font color=red>*</font>Barang yang anda pesan akan dikirim setelah anda melakukan konfirmasi pembayaran.<br/>
	  <font color=red>*</font>Apabila Anda tidak melakukan pembayaran dalam 3 hari, <br />maka data order Anda akan terhapus (transaksi batal).<br/><br/>
<a href=media.php?module=tampilorder&act=konfirmasi&id=$r[id_orders] class='button'>Konfirmasi Pembayaran</a><br/>
      </div>
      </div>
      </div>
	  </div>";
	  			
			
echo "<div class='pull-right hidden-phone'>
      <div class='span-anekaweb1'>
	  <div class='box-wrapper'>
	  <div class='inside'>
	  <table class='table shopping-cart-table-total'>
	  <tr>
	  <th class='alignright'>Total :</th>
	  <th> Rp. $total_rp</th>
	  </tr>
	  <tr>";
	  if($totalberat!=0){ 
echo "<th class='alignright'>Ongkos Kirim Tujuan Kota Anda :</th>
	  <th> Rp. $ongkoskirim1_rp</th>
	  </tr>
	  <tr>
	  <th class='alignright'>Total Berat :</th>
	  <th>$totalberat/Kg</th>
	  </tr>
	  <tr>
	  <th class='alignright'>Total Ongkos Kirim :</th>
	  <th>Rp. $ongkoskirim_rp</th>
	  </tr>";
	  }
echo "<tr>
	  <td class='alignright'><h4>GRAND TOTAL :</h4></td>
	  <td><h4>Rp. $grandtotal_rp</h4></td>
	  </tr>
	  </table>
	  </div>
	  </div>
	  </div>
	  </div>
	  </div>";
		}
	}
	else{
		echo"<div class=ket><b>Tidak ada produk yang anda pesan.</b></div>";
	}
?>
</div>
</div>
</div>
    <?php include "$f[folder]/modul/sidebar/sidebar-akun.php";?>
        
        
        </div>
      </div>
    </div>
  </section>
  <div id="push"></div>
</div>